<x-layout>
    <div class="container mx-auto mt-8 px-4">
        <x-ui.header>
            <!-- Page title -->
            <x-ui.title>
                Search for a Vehicle
            </x-ui.title>
        </x-ui.header>
        <!-- form to search for specific vehicles on the website -->
        @include('components.Search-Vehicle-Form.Form')
    </div>
</x-layout>
