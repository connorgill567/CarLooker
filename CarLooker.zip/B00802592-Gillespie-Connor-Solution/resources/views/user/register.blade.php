<x-layout>

    {{-- card with fields to register a user account --}}
    <x-ui.card class="mt-20">
        <x-slot:header>
            <x-ui.title>Register</x-ui.title>
        </x-slot:header>

        <form method="POST" action="{{ route('register') }}"> @csrf <div class="mt-2"> <x-ui.form.input label="Name"
                    name="name" value="{{ old('name') }}" /> </div>
            <div class="mt-2">
                {{-- email field --}}
                <x-ui.form.input label="Email" name="email" value="{{ old('email') }}" />
            </div>
            {{-- password field --}}
            <div class="mt-2"> <x-ui.form.input label="Password" name="password" type="password"
                    value="{{ old('password') }}" /> </div>
            {{-- confirm password field --}}
            <div class="mt-2"> <x-ui.form.input label="Confirm Password" name="password_confirmation"
                    value="{{ old('password_confirmation') }}" type="password" /> </div>
            <div class="flex items-center gap-2 mt-8">
                {{-- register button --}}
                <x-ui.button variant="dark">Register</x-ui.button>
                {{-- cancel button --}}
                <x-ui.link variant="light" href="/">Cancel</x-ui.link>
            </div>
        </form>

    </x-ui.card>
</x-layout>
