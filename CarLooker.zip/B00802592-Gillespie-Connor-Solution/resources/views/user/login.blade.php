<x-layout>

    {{-- card with email and password fields --}}
        <x-ui.card class="mt-20">
            <x-slot:header>
                <x-ui.title>Login</x-ui.title>
            </x-slot:header>

            <form method="POST" action="{{ route('login') }}">
                @csrf
                {{-- email field --}}
                <div class="mt-2">
                    <x-ui.form.input label="Email" name="email" value="{{ old('email', $user->email) }}" />
                </div>
                {{-- password field--}}
                <div class="mt-2">
                    <x-ui.form.input label="Password" name="password" type="password" value="{{ old('password', $user->password) }}" />
                </div>

                <!-- form controls -->
                <div class="flex items-center gap-2 mt-8">
                    <x-ui.button variant="dark">Login</x-ui.button>
                    <x-ui.link variant="light" href="/">Cancel</x-ui.link>
                </div>

            </form>
        </x-ui.card>
</x-layout>
