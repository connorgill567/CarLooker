<x-layout>
    <x-ui.breadcrumb :crumbs="[
        'Home'=>route('home'),
        'Vehicles'=>route('vehicles.index'),
        $vehicle->id => route('vehicles.show',['id'=>$vehicle->id])
    ]"/>

    <!-- header -->
    <x-ui.header>
        <x-ui.title>Vehicle Details</x-ui.title>
        <!-- Back button -->
        <x-ui.link href="{{route('vehicles.index')}}" class="flex gap-2 items-center">
            <x-ui.svg.arrow left/>
            <span>Back</span>
         </x-ui.link>
    </x-ui.header>

    <div class="flex gap-4">
        <!-- Vehicle details card -->
        <x-ui.card class="w-1/2">
            <x-slot:header class="flex gap-2 items-center">
                <x-ui.title>{{ $vehicle->make }} {{ $vehicle->model }}</x-ui.title>
            </x-slot:header>
            <!-- Vehicle image -->
            @if ($vehicle->image)
            <img src="{{ Storage::url($vehicle->image) }}" alt="{{ $vehicle->make }} {{ $vehicle->model }}" class="w-64">
        @endif
            <!-- Vehicle details -->
            <x-ui.display name="Year" value="{{ $vehicle->year }}"/>
            <x-ui.display name="Registration" value="{{ $vehicle->registration }}"/>
            <x-ui.display name="Fuel Type" value="{{ $vehicle->fuel_type }}"/>
            <x-ui.display name="Body Type" value="{{ $vehicle->body_type }}"/>
            <x-ui.display name="Transmission Type" value="{{ $vehicle->transmission_type }}"/>
            <x-ui.display name="CC" value="{{ $vehicle->cc }}"/>
            <x-ui.display name="No. Doors" value="{{ $vehicle->no_doors }}"/>
            <div class="flex gap-3 mt-4">
                <!-- Vehicle edit button -->
                <x-ui.link variant="blue" href="{{ route('vehicles.edit', ['id' => $vehicle->id]) }}">
                    Edit
                </x-ui.link>
                <!-- Vehicle delete button -->
                <x-ui.link variant="red" href="{{ route('vehicles.delete', ['id' => $vehicle->id]) }}">
                    Delete
                </x-ui.link>
            </div>
        </x-ui.card>

        <!-- Service history card -->
        <x-ui.card class="w-1/2">
            <x-slot:header>
                <x-ui.title>Service History</x-ui.title>
            </x-slot:header>

            <table class="w-full">
                <thead>
                    <tr>
                        <!-- Service record headings -->
                        <th class="px-4 py-2">Service Date</th>
                        <th class="px-4 py-2">By</th>
                        <th class="px-4 py-2">Mileage</th>
                        <th class="px-4 py-2">Cost</th>
                        <th class="px-4 py-2">Description</th>
                    </tr>
                </thead>
                <tbody>
                    <!-- Service record information -->
                    @foreach ($vehicle->serviceRecords as $record)
                        <tr>
                            <td class="border px-4 py-2">{{ $record->service_date }}</td>
                            <td class="border px-4 py-2">{{ $record->service_by }}</td>
                            <td class="border px-4 py-2">{{ $record->mileage }}</td>
                            <td class="border px-4 py-2">{{ $record->cost }}</td>
                            <td class="border px-4 py-2">{{ $record->description }}</td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
            <div class="flex gap-3 mt-4">
                <!-- Add a new service record for the vehicle -->
                <x-ui.link variant="blue" href="{{ route('vehicles.addService', ['id' => $vehicle->id]) }}">
                    Add Service
                </x-ui.link>
                @foreach ($vehicle->serviceRecords as $record)
                <!-- Edit a service record for the vehicle -->
                    <x-ui.link variant="blue" href="{{ route('service-records.edit', ['id' => $record->id]) }}">
                        Edit Service
                    </x-ui.link>
                @endforeach
                @foreach ($vehicle->serviceRecords as $record)
                <!-- Delete a service record for the vehicle -->
                <x-ui.link variant="red" href="{{ route('service-records.delete', ['id' => $vehicle->id]) }}">
                    Delete Service
                </x-ui.link>
                @endforeach
            </div>
        </x-ui.card>
    </div>
</x-layout>
