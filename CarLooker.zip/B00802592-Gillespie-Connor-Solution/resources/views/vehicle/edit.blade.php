<x-layout>
    <x-ui.breadcrumb :crumbs="[
        'Home' => route('home'),
        'Vehicles' => route('vehicles.index'),
        $vehicle->id => route('vehicles.show', ['id' => $vehicle->id]),
    ]" />

    <!-- header -->
    <x-ui.header>
        <x-ui.title>Update Vehicle</x-ui.title>
    </x-ui.header>

    <x-ui.card>
        <!-- form to update vehicle information -->
        <form method="POST" action="{{ route('vehicles.update', ['id' => $vehicle->id]) }}" enctype="multipart/form-data">
            @csrf
            @method('PUT')
            <!-- fields to input vehicle information -->
            @include('vehicle._inputs', ['vehicle' => $vehicle])

            <!-- form controls -->
            <div class="mt-2 flex items-center gap-2">
                <x-ui.button variant="blue" type="submit">
                    Save
                </x-ui.button>
                <x-ui.link href="{{ route('vehicles.index') }}">
                    Cancel
                </x-ui.link>
            </div>
        </form>
    </x-ui.card>
</x-layout>
