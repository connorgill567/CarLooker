<x-layout>
    <!-- breadcrumbs -->
    <x-ui.breadcrumb :crumbs="[
        'Home'=>route('home'),
        'Vehicles'=>route('vehicles.index'),
        'Create'=>'#'
    ]"/>

    <!-- header -->
    <x-ui.header>
        <x-ui.title>Create Vehicle</x-ui.title>
    </x-ui.header>

    <!-- form -->
    <x-ui.card>
        <!-- stores the vehicle onto the database -->
        <form method="POST" action="{{ route('vehicles.store') }}" enctype="multipart/form-data">
            @csrf
            <!-- input fields  -->
            @include('vehicle._inputs', ['vehicle' => new App\Models\Vehicle()])

            <!-- form controls -->
            <div class="mt-2 flex items-center gap-2">
                <x-ui.button type="submit" variant="blue">
                    Create
                </x-ui.button>
                <!-- Cancel button sends the user back to the home page -->
                <x-ui.link href="{{ route('vehicles.index') }}">Cancel</x-ui.link>
            </div>
        </form>
    </x-ui.card>
</x-layout>
