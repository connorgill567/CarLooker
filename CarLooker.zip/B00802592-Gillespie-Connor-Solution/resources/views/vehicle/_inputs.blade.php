<!-- Make -->
<div class="mt-2">
    <x-ui.form.input label="Make" name="make" value="{{ old('make', $vehicle->make) }}" />
</div>

<!-- Model -->
<div class="mt-2">
    <x-ui.form.input label="Model" name="model" value="{{ old('model', $vehicle->model) }}" />
</div>

<!-- Year -->
<div class="mt-2">
    <x-ui.form.input label="Year" name="year" type="number" value="{{ old('year', $vehicle->year) }}" />
</div>

<!-- Registration -->
<div class="mt-2">
    <x-ui.form.input label="Registration" name="registration" value="{{ old('registration', $vehicle->registration) }}" />
</div>

<!-- Fuel Type -->
<div class="mt-2">
    <x-ui.form.select label="Fuel Type" :options="['Diesel', 'Petrol', 'Electric', 'Hybrid']" name="fuel_type" :selected="old('fuel_type', $vehicle->fuel_type)" />
</div>

<!-- Body Type -->
<div class="mt-2">
    <x-ui.form.input label="Body Type" name="body_type" value="{{ old('body_type', $vehicle->body_type) }}" />
</div>

<!-- Transmission Type -->
<div class="mt-2">
    <x-ui.form.select label="Transmission Type" :options="['Manual', 'Automatic']" name="transmission_type" :selected="old('transmission_type', $vehicle->transmission_type)" />
</div>

<!-- CC -->
<div class="mt-2">
    <x-ui.form.input label="CC" name="cc" type="number" value="{{ old('cc', $vehicle->cc) }}" />
</div>

<!-- No. Doors -->
<div class="mt-2">
    <x-ui.form.input label="No. Doors" name="no_doors" type="number" value="{{ old('no_doors', $vehicle->no_doors) }}" />
</div>

<!-- Image uploader -->
<div class="mt-2">
    <x-ui.form.input-file label="Image" name="image" type="file" :value="old('image', $vehicle->image)" />
    @if ($vehicle->image && !old('image'))
        <div class="mt-2">
            <img src="{{ Storage::url($vehicle->image) }}" alt="{{ $vehicle->make }} {{ $vehicle->model }}" class="w-64">
        </div>
    @endif
</div>
