<x-layout>
    <!-- breadcrumb -->
    <x-ui.breadcrumb :crumbs="['Home' => route('home'), 'Vehicles' => route('vehicles.index')]" />

    <!-- header -->
    <x-ui.header>
        <x-ui.title>Vehicles</x-ui.title>
        @can('create', App\Models\Vehicle::class)
            <x-ui.link variant="blue" href="{{ route('vehicles.create') }}">Create</x-ui.link>
        @endcan
    </x-ui.header>
        <!-- Card with vehicle information -->
    <x-ui.card>
        <x-ui.table>
            <x-slot:head>
                <x-ui.table.col>
                        <!-- table headings -->
                    <x-ui.link-sort name="id">Id</x-ui.sort-link>
                </x-ui.table.col>
                <x-ui.table.col>
                    <x-ui.link-sort name="make">Make</x-ui.link-sort>
                </x-ui.table.col>
                <x-ui.table.col>
                    <x-ui.link-sort name="model">Model</x-ui.link-sort>
                </x-ui.table.col>
                <x-ui.table.col>
                    <x-ui.link-sort name="year">Year</x-ui.link-sort>
                </x-ui.table.col>
                <x-ui.table.col>
                    <x-ui.link-sort name="registration">Registeration</x-ui.link-sort>
                </x-ui.table.col>
                <x-ui.table.col>
                    <x-ui.link-sort name="fuel_type">Fuel Type</x-ui.link-sort>
                </x-ui.table.col>
                <x-ui.table.col>
                    <x-ui.link-sort name="body_type">Body Type</x-ui.link-sort>
                </x-ui.table.col>
                <x-ui.table.col>
                    <x-ui.link-sort name="transmission_type">Transmission Type</x-ui.link-sort>
                </x-ui.table.col>
                <x-ui.table.col>
                    <x-ui.link-sort name="cc">CC</x-ui.link-sort>
                </x-ui.table.col>
                <x-ui.table.col>
                    <x-ui.link-sort name="no_doors">Doors</x-ui.link-sort>
                </x-ui.table.col> <x-ui.table.col class="text-right">Actions</x-ui.table.col>
            </x-slot:head>
                <!-- vehicle data taken from database onto the card -->
            @foreach ($vehicles as $vehicle)
                <x-ui.table.row hover>
                    <x-ui.table.cell>{{ $vehicle->id }}</x-ui.table.cell>
                    <x-ui.table.cell>{{ $vehicle->make }}</x-ui.table.cell>
                    <x-ui.table.cell>{{ $vehicle->model }}</x-ui.table.cell>
                    <x-ui.table.cell>{{ $vehicle->year }}</x-ui.table.cell>
                    <x-ui.table.cell>{{ $vehicle->registration }}</x-ui.table.cell>
                    <x-ui.table.cell>{{ $vehicle->fuel_type }}</x-ui.table.cell>
                    <x-ui.table.cell>{{ $vehicle->body_type }}</x-ui.table.cell>
                    <x-ui.table.cell>{{ $vehicle->transmission_type }}</x-ui.table.cell>
                    <x-ui.table.cell>{{ $vehicle->cc }}</x-ui.table.cell>
                    <x-ui.table.cell>{{ $vehicle->no_doors }}</x-ui.table.cell>
                    <x-ui.table.cell class="flex justify-end text-right">
                            <!-- icon to edit the vehicle information -->
                        @can('update', $vehicle)
                            <x-ui.link href="{{ route('vehicles.edit', ['id' => $vehicle->id]) }}">
                                <x-ui.svg.edit />
                            </x-ui.link>
                        @endcan
                        <!-- icon to show the vehicle information -->
                        @can('view', $vehicle)
                            <x-ui.link href="{{ route('vehicles.show', ['id' => $vehicle->id]) }}">
                                <x-ui.svg.eye />
                            </x-ui.link>
                        @endcan
                    </x-ui.table.cell>
                </x-ui.table.row>
            @endforeach
        </x-ui.table>
        <!-- pagination -->
        {{ $vehicles->links() }}
    </x-ui.card>
</x-layout>
