<x-layout>
    <div class="container mx-auto py-10">
        <h1 class="text-4xl font-bold mb-6 text-gray-800">About CarLooker</h1>

        <div class="bg-white rounded-lg shadow-lg p-6 mb-8">
            <p class="text-xl text-gray-700 mb-4">Welcome to CarLooker, the ultimate vehicle management system designed for car enthusiasts like you.</p>
            
            <p class="text-lg text-gray-600 mb-6">At CarLooker, we understand your passion for cars and the importance of keeping track of your prized possessions. Our platform provides a comprehensive solution to manage your vehicle collection, whether you own classic cars, sports cars, or everyday vehicles.</p>
            
            <p class="text-lg text-gray-600 mb-6">With CarLooker, you can easily store and access detailed information about each vehicle in your collection, including make, model, year, registration, fuel type, body type, transmission type, engine size, and more. Our intuitive interface makes it effortless to add, edit, and view your vehicles' details.</p>
            
            <p class="text-lg text-gray-600">CarLooker is built using cutting-edge technologies to ensure a seamless and efficient user experience:</p>
        </div>
    </x-layout>