<x-layout>
    @include('components.HomePage.HeroSection')
    @include('components.HomePage.FeatureSection')
    @include('components.HomePage.CommunitySection')
</x-layout>
