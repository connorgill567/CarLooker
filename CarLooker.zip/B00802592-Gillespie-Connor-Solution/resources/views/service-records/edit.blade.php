
<x-layout>
    <!-- breadcrumbs -->
    <x-ui.breadcrumb :crumbs="[
        'Home'=>route('home'),
        'Vehicles'=>route('vehicles.index'),
        $serviceRecord->vehicle->id => route('vehicles.show',['id'=>$serviceRecord->vehicle->id]),
        'Edit Service Record' => null
    ]"/>

    <!-- header -->
    <x-ui.header>
        <x-ui.title>Edit Service Record for {{ $serviceRecord->vehicle->make }} {{ $serviceRecord->vehicle->model }}</x-ui.title>
    </x-ui.header>

    <x-ui.card>
        <!-- form -->
        <form method="POST" action="{{ route('service-records.update', ['id' => $serviceRecord->id]) }}">
            @csrf
            @method('PUT')

            @include('service-records._form', ['serviceRecord' => $serviceRecord])

            <!-- form controls -->
            <div class="mt-4 flex items-center gap-2">
            <!-- update button -->
                <x-ui.button variant="blue" type="submit">
                    Update
                </x-ui.button>
                <!-- delete button -->
                <x-ui.link href="{{ route('vehicles.show', ['id' => $serviceRecord->vehicle->id]) }}">
                    Cancel
                </x-ui.link>
            </div>
        </form>
    </x-ui.card>
</x-layout>
