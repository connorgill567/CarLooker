<x-layout>
    <!-- breadcrumbs -->
    <x-ui.breadcrumb :crumbs="[
        'Home'=>route('home'),
        'Vehicles'=>route('vehicles.index'),
        $vehicle->id => route('vehicles.show',['id'=>$vehicle->id]),
    ]"/>

    <!-- header -->
    <x-ui.header>
        <x-ui.title>Add Service Record for {{ $vehicle->make }} {{ $vehicle->model }}</x-ui.title>
    </x-ui.header>

    <x-ui.card>
        <!-- form -->
        <form method="POST" action="{{ route('service-records.store', ['id' => $vehicle->id]) }}">
            @csrf
            <!-- input fields for service record  -->
            @include('service-records._form', ['serviceRecord' => new App\Models\ServiceRecord()])

            <!-- form controls -->
            <div class="mt-4 flex items-center gap-2">
                <!-- save button -->
                <x-ui.button variant="blue" type="submit">
                    Save
                </x-ui.button>
                <!-- cancel button -->
                <x-ui.link href="{{ route('vehicles.show', ['id' => $vehicle->id]) }}">
                    Cancel
                </x-ui.link>
            </div>
        </form>
    </x-ui.card>
</x-layout>
