<<x-layout>
    <!-- breadcrumbs -->
    <x-ui.breadcrumb :crumbs="[
        'Home'=>route('home'),
        'Vehicles'=>route('vehicles.index'),
        'Delete Service'=>route('service-records.delete', ['id'=>$vehicle->id])
    ]"/>

    <!-- header -->
    <x-ui.header>
        <x-ui.title>Are you sure you want to delete this service?</x-ui.title>
    </x-ui.header>

    <div class="flex gap-4">
         <!-- Service history card -->
         <x-ui.card class="w-1/2">
            <x-slot:header>
                <x-ui.title>Service History</x-ui.title>
            </x-slot:header>

            <table class="w-full">
                <thead>
                    <tr>
                        <!-- table headings-->
                        <th class="px-4 py-2">Service Date</th>
                        <th class="px-4 py-2">By</th>
                        <th class="px-4 py-2">Mileage</th>
                        <th class="px-4 py-2">Cost</th>
                        <th class="px-4 py-2">Description</th>
                    </tr>
                </thead>
                <tbody>
                    <!-- Service record data from the database-->
                    @foreach ($vehicle->serviceRecords as $record)
                        <tr>
                            <td class="border px-4 py-2">{{ $record->service_date }}</td>
                            <td class="border px-4 py-2">{{ $record->service_by }}</td>
                            <td class="border px-4 py-2">{{ $record->mileage }}</td>
                            <td class="border px-4 py-2">{{ $record->cost }}</td>
                            <td class="border px-4 py-2">{{ $record->description }}</td>
                            </td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
            <div class="mt-4 flex gap-x-4">
                <!-- form method to delete the service record -->
                <form method="POST" action="{{ route('service-records.destroy', ['id' => $record->id]) }}" class="m-0">                    @csrf()
                    @method('DELETE')
                    <!-- delete button-->
                    <x-ui.button variant="red" type="submit">
                        Delete
                    </x-ui.button>
                </form>
                <!-- cancel button -->
                <x-ui.link variant="blue" href="{{ route('vehicles.show', ['id' => $record->id]) }}">
                Cancel
            </x-ui.link>
            </div>
         </x-ui.card>
    </div>
</x-layout>
