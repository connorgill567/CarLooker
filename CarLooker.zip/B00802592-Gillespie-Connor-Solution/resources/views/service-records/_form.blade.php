
<!-- Service Date -->
<div class="mt-2">
    <x-ui.form.input label="Service Date" name="service_date" type="date" value="{{ old('service_date', $serviceRecord->service_date) }}" />
</div>

<!-- Service By -->
<div class="mt-2">
    <x-ui.form.input label="Service By" name="service_by" value="{{ old('service_by', $serviceRecord->service_by) }}" />
</div>

<!-- Mileage -->
<div class="mt-2">
    <x-ui.form.input label="Mileage" name="mileage" type="number" value="{{ old('mileage', $serviceRecord->mileage) }}" />
</div>

<!-- Cost -->
<div class="mt-2">
    <x-ui.form.input label="Cost" name="cost" type="text" value="{{ old('cost', $serviceRecord->cost) }}" placeholder="e.g., £100.00" /></div>

<!-- Description -->
<div class="mt-2">
    <x-ui.form.textarea label="Description" name="description">{{ old('description') }}</x-ui.form.textarea>
</div>
