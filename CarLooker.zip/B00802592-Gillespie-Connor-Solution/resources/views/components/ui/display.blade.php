@props([
    'name',
    'value'
])

<div {{$attributes->merge(['class' => 'flex border-b border-slate-200 sm:py-2 md:py-3 rounded-md'])}}>
    <span class="font-bold text-black dark:text-black mr-5">
        {{$name}}
    </span>
    <span class="text-black-500">
        {{$value}}
    </span>
</div>

