<div class="flex justify-between items-baseline border-b border-gray-700 pb-1 my-5">
    {{ $slot }}
</div>



