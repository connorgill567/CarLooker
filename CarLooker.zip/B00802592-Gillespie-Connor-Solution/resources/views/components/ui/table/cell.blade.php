{{--whitespace-nowrap--}}
<td {{$attributes->merge(['class' => 'px-3 py-2 font-medium text-gray-800'])}}>
    {{$slot}}
</td>

