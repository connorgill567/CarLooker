<th scope="col" {{$attributes->merge(['class' => 'px-3 py-2 text-sm text-left font-bold text-gray-900 uppercase'])}} >
    {{$slot}}
</th>
