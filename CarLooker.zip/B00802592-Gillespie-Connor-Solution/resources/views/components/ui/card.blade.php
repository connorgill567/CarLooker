<div {{ $attributes->merge(['class' => "bg-white shadow-md rounded-lg overflow-hidden"]) }}>
    @isset($header)
        <div {{ $header->attributes->merge(['class' => "px-6 py-4 bg-gray-100 border-b border-gray-200"]) }}>
            {{ $header }}
        </div>
    @endisset

    <div class="p-6">
        {{ $slot }}
    </div>

    @isset($footer)
        <div {{ $footer->attributes->merge(['class' => "px-6 py-4 bg-gray-100 border-t border-gray-200"]) }}>
            {{ $footer }}
        </div>
    @endisset
</div>
