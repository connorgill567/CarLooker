<nav {{ $attributes->merge(["class" => "flex gap-6 bg-gray-50 px-4 py-3 border-b"]) }}>  
 {{ $slot}}
</nav>