<div class="bg-gray-900 text-white py-20">
    <div class="container mx-auto px-4">
        <h1 class="text-5xl font-bold mb-4">Welcome to CarLooker</h1>
        <p class="text-xl mb-8">The Ultimate Vehicle Management System for Car Enthusiasts</p>
        <a href="{{ route('vehicles.index') }}" class="bg-blue-500 hover:bg-blue-600 text-white font-bold py-3 px-6 rounded-lg">View Vehicles</a>
    </div>
</div>
