<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{{ $title ?? 'CarLooker' }}</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js"></script>
</head>

<body class="flex flex-col min-h-screen bg-gray-100">

    <!-- navbar -->
    <header class="bg-gray-900">
        <x-ui.nav class="justify-between items-center">
            <!-- main menu options -->
            <div class="flex items-center gap-6">
                <a href="/">
                    <img src="{{ asset('images/CarLookerLogo.webp') }}" class="h-20 rounded-full transform hover:scale-110 transition-transform duration-300" alt="Website Logo">
                </a>
                <x-ui.nav.link href="{{route('home')}}" class="text-black text-lg font-semibold hover:text-blue-300">Home</x-ui.nav.link>
                <x-ui.nav.link href="{{route('about')}}" class="text-black text-lg font-semibold hover:text-blue-300">About</x-ui.nav.link>
                <x-ui.nav.link href="{{route('contact')}}" class="text-black text-lg font-semibold hover:text-blue-300">Contact us</x-ui.nav.link>
                <x-ui.nav.link href="{{route('vehicles.index')}}" class="text-black text-lg font-semibold hover:text-blue-300">Cars</x-ui.nav.link>
            </div>
            <!-- search query in the nav bar -->

            <x-ui.search-bar.search-bar></x-ui.search-bar.search-bar>

            <!-- login/register/logout menu options -->
            <x-ui.auth.identity class="text-white text-lg font-semibold" />
        </x-ui.nav>
    </header>

    <!-- display flash message -->
    <x-ui.flash />

    <!-- main page slot -->
    <main class="container mx-auto my-8 flex-auto">
        {{ $slot }}
    </main>

    <!-- footer -->
    <footer class="bg-gray-900 text-white px-4 py-6 text-center">
        <div class="flex flex-col items-center gap-4">
            <div class="text-lg font-semibold">Copyright @ {{ date("Y") }} CarLooker</div>
        </div>
    </footer>
</body>
</html>
