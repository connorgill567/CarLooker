<x-layout>
    <div class="container mx-auto py-10">
        <h1 class="text-4xl font-bold mb-6 text-gray-800">Contact Us</h1>

        @include('components.ContactForm.ContactFormSection')
        @include('components.ContactForm.ContactInfo')
    </div>
</x-layout>
