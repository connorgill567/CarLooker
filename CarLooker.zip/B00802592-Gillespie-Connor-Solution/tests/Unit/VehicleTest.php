<?php

namespace Tests\Unit;

use App\Models\User;
use App\Models\Vehicle;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class VehicleTest extends TestCase
{
    use RefreshDatabase;

    public function testVehicleCreation()
{
    $user = User::factory()->create();
    $vehicleData = [
        'make' => 'Honda',
        'model' => 'Civic',
        'year' => 2020,
        'registration' => 'ABC123',
        'body_type' => 'Hatchback',
        'fuel_type' => 'Petrol',
        'transmission_type' => 'Automatic',
        'cc' => 2500,
        'no_doors' => 2,
    ];

    $vehicle = Vehicle::create($vehicleData);

    $this->assertDatabaseHas('vehicles', [
        'make' => 'Honda',
        'model' => 'Civic',
        'year' => 2020,
        'registration' => 'ABC123',
        'body_type' => 'Hatchback',
        'fuel_type' => 'Petrol',
        'transmission_type' => 'Automatic',
        'cc' => '2500',
        'no_doors' => '2',
    ]);
}


}

