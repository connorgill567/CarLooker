<?php
namespace Tests\Feature;

use App\Models\User;
use Tests\TestCase;

class AuthenticationTest extends TestCase
{
    public function testUserCannotAccessVehiclePageWithoutAuthentication()
    {
        $response = $this->get('/vehicles');  
        $response->assertRedirect('/login');
    }

    public function testAuthenticatedUserCanAccessVehiclePage()
    {
        $user = User::factory()->create();
        $response = $this->actingAs($user)->get('/vehicles');
        $response->assertStatus(200);
    }
}


