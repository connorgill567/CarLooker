
<div class="p-1.5 overflow-hidden overflow-x-auto min-w-full align-middle border rounded-lg">
    <table class="min-w-full divide-y divide-gray-200">

        <thead <?php echo e($head->attributes->merge(['class' => 'bg-gray-50'])); ?>>
            <tr>
                <?php echo e($head); ?>

            </tr>
        </thead>

        <tbody class="divide-y divide-gray-200">
            <?php echo e($slot); ?>

        </tbody>

    </table>

</div>

<?php /**PATH C:\Users\connor\Desktop\CarLooker\resources\views/components/ui/table/index.blade.php ENDPATH**/ ?>