<div class="mt-8">
    <h2 class="text-2xl font-bold mb-4 text-gray-800">Contact Information</h2>
    <p class="text-lg text-gray-600">If you prefer to reach out to us directly, you can use the following contact information:</p>

    <ul class="mt-4 space-y-2 text-lg text-gray-600">
        <li>
            <span class="font-medium">Email:</span> info@carlooker.com
        </li>
        <li>
            <span class="font-medium">Phone:</span> +44 28 9123 4567
        </li>
        <li>
            <span class="font-medium">Address:</span> 123 Albert Lane
            Newtownabbey
            BT36 7XY
            County Antrim
            Northern Ireland
        </li>
    </ul>
</div>
<?php /**PATH C:\Users\conno\CarLooker\resources\views/components/ContactForm/ContactInfo.blade.php ENDPATH**/ ?>