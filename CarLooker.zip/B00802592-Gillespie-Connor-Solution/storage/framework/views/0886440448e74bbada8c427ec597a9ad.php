<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['name']) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['name']); ?>
<?php foreach (array_filter((['name']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<?php
    $sort = request()->input('sort') ?? 'id';
    $direction = request()->input('direction') ?? 'asc';

    // check if named field being sorted and display asc or desc icon otherwise display sort icon
    $url = ($name == $sort && $direction == 'asc') ? 
        request()->fullUrlWithQuery(['sort'=>$name, 'direction'=>'desc']) :
        request()->fullUrlWithQuery(['sort'=>$name, 'direction'=>'asc']);    
?>

<div class="flex items-center">
    <?php echo e($slot); ?>

    <?php if($name == $sort): ?>
        <a href="<?php echo e($url); ?>"><?php if (isset($component)) { $__componentOriginald414bc1e2a9586a24098fef16e0fe866 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald414bc1e2a9586a24098fef16e0fe866 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.svg.sort','data' => ['direction' => ''.e($direction).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('ui.svg.sort'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['direction' => ''.e($direction).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald414bc1e2a9586a24098fef16e0fe866)): ?>
<?php $attributes = $__attributesOriginald414bc1e2a9586a24098fef16e0fe866; ?>
<?php unset($__attributesOriginald414bc1e2a9586a24098fef16e0fe866); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald414bc1e2a9586a24098fef16e0fe866)): ?>
<?php $component = $__componentOriginald414bc1e2a9586a24098fef16e0fe866; ?>
<?php unset($__componentOriginald414bc1e2a9586a24098fef16e0fe866); ?>
<?php endif; ?></a>        
    <?php else: ?>
        <a href="<?php echo e($url); ?>"><?php if (isset($component)) { $__componentOriginald414bc1e2a9586a24098fef16e0fe866 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald414bc1e2a9586a24098fef16e0fe866 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.svg.sort','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('ui.svg.sort'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald414bc1e2a9586a24098fef16e0fe866)): ?>
<?php $attributes = $__attributesOriginald414bc1e2a9586a24098fef16e0fe866; ?>
<?php unset($__attributesOriginald414bc1e2a9586a24098fef16e0fe866); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald414bc1e2a9586a24098fef16e0fe866)): ?>
<?php $component = $__componentOriginald414bc1e2a9586a24098fef16e0fe866; ?>
<?php unset($__componentOriginald414bc1e2a9586a24098fef16e0fe866); ?>
<?php endif; ?></a>
    <?php endif; ?>
</div>
<?php /**PATH C:\Users\conno\CarLooker\resources\views/components/ui/link-sort.blade.php ENDPATH**/ ?>