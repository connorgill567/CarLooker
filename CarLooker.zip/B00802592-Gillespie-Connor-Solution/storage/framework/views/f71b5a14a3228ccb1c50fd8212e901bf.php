<!-- Make -->
<div class="mt-2">
    <?php if (isset($component)) { $__componentOriginalc3af3653dc31a14448cdb0b348832110 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc3af3653dc31a14448cdb0b348832110 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.form.input','data' => ['label' => 'Make','name' => 'make','value' => ''.e(old('make', $vehicle->make)).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('ui.form.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Make','name' => 'make','value' => ''.e(old('make', $vehicle->make)).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc3af3653dc31a14448cdb0b348832110)): ?>
<?php $attributes = $__attributesOriginalc3af3653dc31a14448cdb0b348832110; ?>
<?php unset($__attributesOriginalc3af3653dc31a14448cdb0b348832110); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc3af3653dc31a14448cdb0b348832110)): ?>
<?php $component = $__componentOriginalc3af3653dc31a14448cdb0b348832110; ?>
<?php unset($__componentOriginalc3af3653dc31a14448cdb0b348832110); ?>
<?php endif; ?>
</div>

<!-- Model -->
<div class="mt-2">
    <?php if (isset($component)) { $__componentOriginalc3af3653dc31a14448cdb0b348832110 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc3af3653dc31a14448cdb0b348832110 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.form.input','data' => ['label' => 'Model','name' => 'model','value' => ''.e(old('model', $vehicle->model)).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('ui.form.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Model','name' => 'model','value' => ''.e(old('model', $vehicle->model)).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc3af3653dc31a14448cdb0b348832110)): ?>
<?php $attributes = $__attributesOriginalc3af3653dc31a14448cdb0b348832110; ?>
<?php unset($__attributesOriginalc3af3653dc31a14448cdb0b348832110); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc3af3653dc31a14448cdb0b348832110)): ?>
<?php $component = $__componentOriginalc3af3653dc31a14448cdb0b348832110; ?>
<?php unset($__componentOriginalc3af3653dc31a14448cdb0b348832110); ?>
<?php endif; ?>
</div>

<!-- Year -->
<div class="mt-2">
    <?php if (isset($component)) { $__componentOriginalc3af3653dc31a14448cdb0b348832110 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc3af3653dc31a14448cdb0b348832110 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.form.input','data' => ['label' => 'Year','name' => 'year','type' => 'number','value' => ''.e(old('year', $vehicle->year)).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('ui.form.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Year','name' => 'year','type' => 'number','value' => ''.e(old('year', $vehicle->year)).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc3af3653dc31a14448cdb0b348832110)): ?>
<?php $attributes = $__attributesOriginalc3af3653dc31a14448cdb0b348832110; ?>
<?php unset($__attributesOriginalc3af3653dc31a14448cdb0b348832110); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc3af3653dc31a14448cdb0b348832110)): ?>
<?php $component = $__componentOriginalc3af3653dc31a14448cdb0b348832110; ?>
<?php unset($__componentOriginalc3af3653dc31a14448cdb0b348832110); ?>
<?php endif; ?>
</div>

<!-- Registration -->
<div class="mt-2">
    <?php if (isset($component)) { $__componentOriginalc3af3653dc31a14448cdb0b348832110 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc3af3653dc31a14448cdb0b348832110 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.form.input','data' => ['label' => 'Registration','name' => 'registration','value' => ''.e(old('registration', $vehicle->registration)).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('ui.form.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Registration','name' => 'registration','value' => ''.e(old('registration', $vehicle->registration)).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc3af3653dc31a14448cdb0b348832110)): ?>
<?php $attributes = $__attributesOriginalc3af3653dc31a14448cdb0b348832110; ?>
<?php unset($__attributesOriginalc3af3653dc31a14448cdb0b348832110); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc3af3653dc31a14448cdb0b348832110)): ?>
<?php $component = $__componentOriginalc3af3653dc31a14448cdb0b348832110; ?>
<?php unset($__componentOriginalc3af3653dc31a14448cdb0b348832110); ?>
<?php endif; ?>
</div>

<!-- Fuel Type -->
<div class="mt-2">
    <?php if (isset($component)) { $__componentOriginal3d764d9aa1637ee21fbd47e006854817 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3d764d9aa1637ee21fbd47e006854817 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.form.select','data' => ['label' => 'Fuel Type','options' => ['Diesel', 'Gasoline', 'Electric', 'Hybrid'],'name' => 'fuel_type','value' => ''.e(old('fuel_type', $vehicle->fuel_type)).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('ui.form.select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Fuel Type','options' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(['Diesel', 'Gasoline', 'Electric', 'Hybrid']),'name' => 'fuel_type','value' => ''.e(old('fuel_type', $vehicle->fuel_type)).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3d764d9aa1637ee21fbd47e006854817)): ?>
<?php $attributes = $__attributesOriginal3d764d9aa1637ee21fbd47e006854817; ?>
<?php unset($__attributesOriginal3d764d9aa1637ee21fbd47e006854817); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3d764d9aa1637ee21fbd47e006854817)): ?>
<?php $component = $__componentOriginal3d764d9aa1637ee21fbd47e006854817; ?>
<?php unset($__componentOriginal3d764d9aa1637ee21fbd47e006854817); ?>
<?php endif; ?>
</div>

<!-- Body Type -->
<div class="mt-2">
    <?php if (isset($component)) { $__componentOriginalc3af3653dc31a14448cdb0b348832110 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc3af3653dc31a14448cdb0b348832110 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.form.input','data' => ['label' => 'Body Type','name' => 'body_type','value' => ''.e(old('body_type', $vehicle->body_type)).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('ui.form.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Body Type','name' => 'body_type','value' => ''.e(old('body_type', $vehicle->body_type)).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc3af3653dc31a14448cdb0b348832110)): ?>
<?php $attributes = $__attributesOriginalc3af3653dc31a14448cdb0b348832110; ?>
<?php unset($__attributesOriginalc3af3653dc31a14448cdb0b348832110); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc3af3653dc31a14448cdb0b348832110)): ?>
<?php $component = $__componentOriginalc3af3653dc31a14448cdb0b348832110; ?>
<?php unset($__componentOriginalc3af3653dc31a14448cdb0b348832110); ?>
<?php endif; ?>
</div>

<!-- Transmission Type -->
<div class="mt-2">
    <?php if (isset($component)) { $__componentOriginal3d764d9aa1637ee21fbd47e006854817 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3d764d9aa1637ee21fbd47e006854817 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.form.select','data' => ['label' => 'Transmission Type','options' => ['Manual', 'Automatic'],'name' => 'transmission_type','value' => ''.e(old('transmission_type', $vehicle->transmission_type)).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('ui.form.select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Transmission Type','options' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(['Manual', 'Automatic']),'name' => 'transmission_type','value' => ''.e(old('transmission_type', $vehicle->transmission_type)).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3d764d9aa1637ee21fbd47e006854817)): ?>
<?php $attributes = $__attributesOriginal3d764d9aa1637ee21fbd47e006854817; ?>
<?php unset($__attributesOriginal3d764d9aa1637ee21fbd47e006854817); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3d764d9aa1637ee21fbd47e006854817)): ?>
<?php $component = $__componentOriginal3d764d9aa1637ee21fbd47e006854817; ?>
<?php unset($__componentOriginal3d764d9aa1637ee21fbd47e006854817); ?>
<?php endif; ?>
</div>

<!-- CC -->
<div class="mt-2">
    <?php if (isset($component)) { $__componentOriginalc3af3653dc31a14448cdb0b348832110 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc3af3653dc31a14448cdb0b348832110 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.form.input','data' => ['label' => 'CC','name' => 'cc','type' => 'number','value' => ''.e(old('cc', $vehicle->cc)).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('ui.form.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'CC','name' => 'cc','type' => 'number','value' => ''.e(old('cc', $vehicle->cc)).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc3af3653dc31a14448cdb0b348832110)): ?>
<?php $attributes = $__attributesOriginalc3af3653dc31a14448cdb0b348832110; ?>
<?php unset($__attributesOriginalc3af3653dc31a14448cdb0b348832110); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc3af3653dc31a14448cdb0b348832110)): ?>
<?php $component = $__componentOriginalc3af3653dc31a14448cdb0b348832110; ?>
<?php unset($__componentOriginalc3af3653dc31a14448cdb0b348832110); ?>
<?php endif; ?>
</div>

<!-- No. Doors -->
<div class="mt-2">
    <?php if (isset($component)) { $__componentOriginalc3af3653dc31a14448cdb0b348832110 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc3af3653dc31a14448cdb0b348832110 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.form.input','data' => ['label' => 'No. Doors','name' => 'no_doors','type' => 'number','value' => ''.e(old('no_doors', $vehicle->no_doors)).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('ui.form.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'No. Doors','name' => 'no_doors','type' => 'number','value' => ''.e(old('no_doors', $vehicle->no_doors)).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc3af3653dc31a14448cdb0b348832110)): ?>
<?php $attributes = $__attributesOriginalc3af3653dc31a14448cdb0b348832110; ?>
<?php unset($__attributesOriginalc3af3653dc31a14448cdb0b348832110); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc3af3653dc31a14448cdb0b348832110)): ?>
<?php $component = $__componentOriginalc3af3653dc31a14448cdb0b348832110; ?>
<?php unset($__componentOriginalc3af3653dc31a14448cdb0b348832110); ?>
<?php endif; ?>
</div>
<?php /**PATH C:\Users\connor\Desktop\CarLooker\resources\views/vehicle/_inputs.blade.php ENDPATH**/ ?>