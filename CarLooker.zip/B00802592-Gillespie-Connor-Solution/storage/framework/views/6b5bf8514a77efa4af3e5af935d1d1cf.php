
<td <?php echo e($attributes->merge(['class' => 'px-3 py-2 font-medium text-gray-800'])); ?>>
    <?php echo e($slot); ?>

</td>

<?php /**PATH C:\Users\conno\CarLooker\resources\views/components/ui/table/cell.blade.php ENDPATH**/ ?>