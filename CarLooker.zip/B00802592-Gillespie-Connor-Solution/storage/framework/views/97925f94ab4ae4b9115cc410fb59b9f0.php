
<!-- Service Date -->
<div class="mt-2">
    <?php if (isset($component)) { $__componentOriginalc3af3653dc31a14448cdb0b348832110 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc3af3653dc31a14448cdb0b348832110 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.form.input','data' => ['label' => 'Service Date','name' => 'service_date','type' => 'date','value' => ''.e(old('service_date', $serviceRecord->service_date)).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('ui.form.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Service Date','name' => 'service_date','type' => 'date','value' => ''.e(old('service_date', $serviceRecord->service_date)).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc3af3653dc31a14448cdb0b348832110)): ?>
<?php $attributes = $__attributesOriginalc3af3653dc31a14448cdb0b348832110; ?>
<?php unset($__attributesOriginalc3af3653dc31a14448cdb0b348832110); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc3af3653dc31a14448cdb0b348832110)): ?>
<?php $component = $__componentOriginalc3af3653dc31a14448cdb0b348832110; ?>
<?php unset($__componentOriginalc3af3653dc31a14448cdb0b348832110); ?>
<?php endif; ?>
</div>

<!-- Service By -->
<div class="mt-2">
    <?php if (isset($component)) { $__componentOriginalc3af3653dc31a14448cdb0b348832110 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc3af3653dc31a14448cdb0b348832110 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.form.input','data' => ['label' => 'Service By','name' => 'service_by','value' => ''.e(old('service_by', $serviceRecord->service_by)).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('ui.form.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Service By','name' => 'service_by','value' => ''.e(old('service_by', $serviceRecord->service_by)).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc3af3653dc31a14448cdb0b348832110)): ?>
<?php $attributes = $__attributesOriginalc3af3653dc31a14448cdb0b348832110; ?>
<?php unset($__attributesOriginalc3af3653dc31a14448cdb0b348832110); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc3af3653dc31a14448cdb0b348832110)): ?>
<?php $component = $__componentOriginalc3af3653dc31a14448cdb0b348832110; ?>
<?php unset($__componentOriginalc3af3653dc31a14448cdb0b348832110); ?>
<?php endif; ?>
</div>

<!-- Mileage -->
<div class="mt-2">
    <?php if (isset($component)) { $__componentOriginalc3af3653dc31a14448cdb0b348832110 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc3af3653dc31a14448cdb0b348832110 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.form.input','data' => ['label' => 'Mileage','name' => 'mileage','type' => 'number','value' => ''.e(old('mileage', $serviceRecord->mileage)).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('ui.form.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Mileage','name' => 'mileage','type' => 'number','value' => ''.e(old('mileage', $serviceRecord->mileage)).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc3af3653dc31a14448cdb0b348832110)): ?>
<?php $attributes = $__attributesOriginalc3af3653dc31a14448cdb0b348832110; ?>
<?php unset($__attributesOriginalc3af3653dc31a14448cdb0b348832110); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc3af3653dc31a14448cdb0b348832110)): ?>
<?php $component = $__componentOriginalc3af3653dc31a14448cdb0b348832110; ?>
<?php unset($__componentOriginalc3af3653dc31a14448cdb0b348832110); ?>
<?php endif; ?>
</div>

<!-- Cost -->
<div class="mt-2">
    <?php if (isset($component)) { $__componentOriginalc3af3653dc31a14448cdb0b348832110 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc3af3653dc31a14448cdb0b348832110 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.form.input','data' => ['label' => 'Cost','name' => 'cost','type' => 'text','value' => ''.e(old('cost', $serviceRecord->cost)).'','placeholder' => 'e.g., £100.00']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('ui.form.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Cost','name' => 'cost','type' => 'text','value' => ''.e(old('cost', $serviceRecord->cost)).'','placeholder' => 'e.g., £100.00']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc3af3653dc31a14448cdb0b348832110)): ?>
<?php $attributes = $__attributesOriginalc3af3653dc31a14448cdb0b348832110; ?>
<?php unset($__attributesOriginalc3af3653dc31a14448cdb0b348832110); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc3af3653dc31a14448cdb0b348832110)): ?>
<?php $component = $__componentOriginalc3af3653dc31a14448cdb0b348832110; ?>
<?php unset($__componentOriginalc3af3653dc31a14448cdb0b348832110); ?>
<?php endif; ?></div>

<!-- Description -->
<div class="mt-2">
    <?php if (isset($component)) { $__componentOriginal6533f4949bed0869bfc088e9a22e363b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6533f4949bed0869bfc088e9a22e363b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.form.textarea','data' => ['label' => 'Description','name' => 'description']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('ui.form.textarea'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Description','name' => 'description']); ?><?php echo e(old('description')); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6533f4949bed0869bfc088e9a22e363b)): ?>
<?php $attributes = $__attributesOriginal6533f4949bed0869bfc088e9a22e363b; ?>
<?php unset($__attributesOriginal6533f4949bed0869bfc088e9a22e363b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6533f4949bed0869bfc088e9a22e363b)): ?>
<?php $component = $__componentOriginal6533f4949bed0869bfc088e9a22e363b; ?>
<?php unset($__componentOriginal6533f4949bed0869bfc088e9a22e363b); ?>
<?php endif; ?>
</div>
<?php /**PATH C:\Users\conno\CarLooker\resources\views/service-records/_form.blade.php ENDPATH**/ ?>