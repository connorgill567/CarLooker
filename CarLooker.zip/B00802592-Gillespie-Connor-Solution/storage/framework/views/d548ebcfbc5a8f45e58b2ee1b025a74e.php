<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23a33f287873b564aaf305a1526eada4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="bg-gray-900 text-white py-20">
        <div class="container mx-auto px-4">
            <h1 class="text-5xl font-bold mb-4">Welcome to CarLooker</h1>
            <p class="text-xl mb-8">The Ultimate Vehicle Management System for Car Enthusiasts</p>
            <a href="<?php echo e(route('vehicles.index')); ?>" class="bg-blue-500 hover:bg-blue-600 text-white font-bold py-3 px-6 rounded-lg">View Vehicles</a>
        </div>
    </div>

    <div class="container mx-auto py-12">
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <a href="<?php echo e(route('vehicles.create')); ?>" class="bg-white rounded-lg shadow-lg p-6 hover:shadow-xl transition duration-300">
                <div class="flex items-center mb-4">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-10 w-10 text-blue-500 mr-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4" />
                    </svg>
                    <h2 class="text-2xl font-bold text-gray-800">Add Vehicles</h2>
                </div>
                <p class="text-lg text-gray-600">Easily add new vehicles to your collection with detailed information such as make, model, year, and more.</p>
            </a>

            <a href="<?php echo e(route('vehicles.index')); ?>" class="bg-white rounded-lg shadow-lg p-6 hover:shadow-xl transition duration-300">
                <div class="flex items-center mb-4">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-10 w-10 text-blue-500 mr-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z" />
                    </svg>
                    <h2 class="text-2xl font-bold text-gray-800">Manage Vehicles</h2>
                </div>
                <p class="text-lg text-gray-600">Update and manage your vehicle information effortlessly. Keep track of important details and maintain an accurate record of your collection.</p>
            </a>

            <a href="<?php echo e(route('vehicles.index')); ?>" class="bg-white rounded-lg shadow-lg p-6 hover:shadow-xl transition duration-300">
                <div class="flex items-center mb-4">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-10 w-10 text-blue-500 mr-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                    </svg>
                    <h2 class="text-2xl font-bold text-gray-800">Search Vehicles</h2>
                </div>
                <p class="text-lg text-gray-600">Quickly find specific vehicles in your collection using powerful search capabilities. Locate the information you need in just a few clicks.</p>
            </a>
        </div>
    </div>

    <div class="bg-gray-100 py-12">
        <div class="container mx-auto text-center">
            <h2 class="text-3xl font-bold mb-4 text-gray-800">Join the CarLooker Community</h2>
            <p class="text-xl text-gray-600 mb-8">Sign up now and start managing your vehicle collection like a pro.</p>
            <a href="<?php echo e(route('register')); ?>" class="bg-blue-500 hover:bg-blue-600 text-white font-bold py-3 px-6 rounded-lg">Get Started</a>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $attributes = $__attributesOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__attributesOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?><?php /**PATH C:\Users\connor\Desktop\CarLooker\resources\views/home.blade.php ENDPATH**/ ?>