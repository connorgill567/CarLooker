<?php if(auth()->guard()->check()): ?>
    <form method="post" action="<?php echo e(route('logout')); ?>" class="flex gap-2 p-0 m-0">
        <?php echo csrf_field(); ?>
        <?php if (isset($component)) { $__componentOriginal587069d3eaa193a2bc584070bfdc47fc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal587069d3eaa193a2bc584070bfdc47fc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.nav.button','data' => ['type' => 'submit']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('ui.nav.button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'submit']); ?>Logout <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal587069d3eaa193a2bc584070bfdc47fc)): ?>
<?php $attributes = $__attributesOriginal587069d3eaa193a2bc584070bfdc47fc; ?>
<?php unset($__attributesOriginal587069d3eaa193a2bc584070bfdc47fc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal587069d3eaa193a2bc584070bfdc47fc)): ?>
<?php $component = $__componentOriginal587069d3eaa193a2bc584070bfdc47fc; ?>
<?php unset($__componentOriginal587069d3eaa193a2bc584070bfdc47fc); ?>
<?php endif; ?>
        <div class="py-1.5 text-gray-400 text-xs">
            (<?php echo e(auth()?->user()?->name); ?>)
        </div>
    </form>
<?php endif; ?>
<?php if(auth()->guard()->guest()): ?>
<div class="flex gap-2 items-center">
    <?php if (isset($component)) { $__componentOriginala7126f5d2314ae77706c18dfdafd2a54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala7126f5d2314ae77706c18dfdafd2a54 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.nav.link','data' => ['href' => ''.e(route('login')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('ui.nav.link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => ''.e(route('login')).'']); ?>Login <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala7126f5d2314ae77706c18dfdafd2a54)): ?>
<?php $attributes = $__attributesOriginala7126f5d2314ae77706c18dfdafd2a54; ?>
<?php unset($__attributesOriginala7126f5d2314ae77706c18dfdafd2a54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala7126f5d2314ae77706c18dfdafd2a54)): ?>
<?php $component = $__componentOriginala7126f5d2314ae77706c18dfdafd2a54; ?>
<?php unset($__componentOriginala7126f5d2314ae77706c18dfdafd2a54); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginala7126f5d2314ae77706c18dfdafd2a54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala7126f5d2314ae77706c18dfdafd2a54 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.nav.link','data' => ['href' => ''.e(route('register')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('ui.nav.link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => ''.e(route('register')).'']); ?>Register <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala7126f5d2314ae77706c18dfdafd2a54)): ?>
<?php $attributes = $__attributesOriginala7126f5d2314ae77706c18dfdafd2a54; ?>
<?php unset($__attributesOriginala7126f5d2314ae77706c18dfdafd2a54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala7126f5d2314ae77706c18dfdafd2a54)): ?>
<?php $component = $__componentOriginala7126f5d2314ae77706c18dfdafd2a54; ?>
<?php unset($__componentOriginala7126f5d2314ae77706c18dfdafd2a54); ?>
<?php endif; ?>
</div>
<?php endif; ?>


<?php /**PATH C:\Users\conno\CarLooker\resources\views/components/ui/auth/identity.blade.php ENDPATH**/ ?>