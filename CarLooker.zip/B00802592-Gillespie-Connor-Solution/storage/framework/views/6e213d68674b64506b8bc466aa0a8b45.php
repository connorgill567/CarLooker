<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23a33f287873b564aaf305a1526eada4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <!-- breadcrumb -->
    <?php if (isset($component)) { $__componentOriginal045477955e5b1d8c9df01934ca3836c0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal045477955e5b1d8c9df01934ca3836c0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.breadcrumb','data' => ['crumbs' => ['Home' => route('home'), 'Vehicles' => route('vehicles.index')]]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('ui.breadcrumb'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['crumbs' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(['Home' => route('home'), 'Vehicles' => route('vehicles.index')])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal045477955e5b1d8c9df01934ca3836c0)): ?>
<?php $attributes = $__attributesOriginal045477955e5b1d8c9df01934ca3836c0; ?>
<?php unset($__attributesOriginal045477955e5b1d8c9df01934ca3836c0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal045477955e5b1d8c9df01934ca3836c0)): ?>
<?php $component = $__componentOriginal045477955e5b1d8c9df01934ca3836c0; ?>
<?php unset($__componentOriginal045477955e5b1d8c9df01934ca3836c0); ?>
<?php endif; ?>

    <!-- header -->
    <?php if (isset($component)) { $__componentOriginalea3ff48ecc2c47bd6007ee32944844eb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalea3ff48ecc2c47bd6007ee32944844eb = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.header','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('ui.header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
        <?php if (isset($component)) { $__componentOriginaleee9904a23975a5389c3cf9a8800e87b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaleee9904a23975a5389c3cf9a8800e87b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.title','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('ui.title'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>Vehicles <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaleee9904a23975a5389c3cf9a8800e87b)): ?>
<?php $attributes = $__attributesOriginaleee9904a23975a5389c3cf9a8800e87b; ?>
<?php unset($__attributesOriginaleee9904a23975a5389c3cf9a8800e87b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaleee9904a23975a5389c3cf9a8800e87b)): ?>
<?php $component = $__componentOriginaleee9904a23975a5389c3cf9a8800e87b; ?>
<?php unset($__componentOriginaleee9904a23975a5389c3cf9a8800e87b); ?>
<?php endif; ?>
        <!-- TBC Q2 - authorise -->
        <?php if (isset($component)) { $__componentOriginal606bedd6108050b8303bc7c381e2387c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal606bedd6108050b8303bc7c381e2387c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.link','data' => ['variant' => 'blue','href' => ''.e(route('vehicles.create')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('ui.link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['variant' => 'blue','href' => ''.e(route('vehicles.create')).'']); ?>Create <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal606bedd6108050b8303bc7c381e2387c)): ?>
<?php $attributes = $__attributesOriginal606bedd6108050b8303bc7c381e2387c; ?>
<?php unset($__attributesOriginal606bedd6108050b8303bc7c381e2387c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal606bedd6108050b8303bc7c381e2387c)): ?>
<?php $component = $__componentOriginal606bedd6108050b8303bc7c381e2387c; ?>
<?php unset($__componentOriginal606bedd6108050b8303bc7c381e2387c); ?>
<?php endif; ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalea3ff48ecc2c47bd6007ee32944844eb)): ?>
<?php $attributes = $__attributesOriginalea3ff48ecc2c47bd6007ee32944844eb; ?>
<?php unset($__attributesOriginalea3ff48ecc2c47bd6007ee32944844eb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalea3ff48ecc2c47bd6007ee32944844eb)): ?>
<?php $component = $__componentOriginalea3ff48ecc2c47bd6007ee32944844eb; ?>
<?php unset($__componentOriginalea3ff48ecc2c47bd6007ee32944844eb); ?>
<?php endif; ?>

    <?php if (isset($component)) { $__componentOriginaldae4cd48acb67888a4631e1ba48f2f93 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldae4cd48acb67888a4631e1ba48f2f93 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.card','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('ui.card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
        <?php if (isset($component)) { $__componentOriginal793d2b22631f88b8a3d00569a12acf88 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal793d2b22631f88b8a3d00569a12acf88 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.table.index','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('ui.table'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
             <?php $__env->slot('head', null, []); ?> 
                <?php if (isset($component)) { $__componentOriginal87a58b477caf2639ca6da313d7b9beb1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal87a58b477caf2639ca6da313d7b9beb1 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.table.col','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('ui.table.col'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>Make <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal87a58b477caf2639ca6da313d7b9beb1)): ?>
<?php $attributes = $__attributesOriginal87a58b477caf2639ca6da313d7b9beb1; ?>
<?php unset($__attributesOriginal87a58b477caf2639ca6da313d7b9beb1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal87a58b477caf2639ca6da313d7b9beb1)): ?>
<?php $component = $__componentOriginal87a58b477caf2639ca6da313d7b9beb1; ?>
<?php unset($__componentOriginal87a58b477caf2639ca6da313d7b9beb1); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginal87a58b477caf2639ca6da313d7b9beb1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal87a58b477caf2639ca6da313d7b9beb1 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.table.col','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('ui.table.col'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>Model <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal87a58b477caf2639ca6da313d7b9beb1)): ?>
<?php $attributes = $__attributesOriginal87a58b477caf2639ca6da313d7b9beb1; ?>
<?php unset($__attributesOriginal87a58b477caf2639ca6da313d7b9beb1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal87a58b477caf2639ca6da313d7b9beb1)): ?>
<?php $component = $__componentOriginal87a58b477caf2639ca6da313d7b9beb1; ?>
<?php unset($__componentOriginal87a58b477caf2639ca6da313d7b9beb1); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginal87a58b477caf2639ca6da313d7b9beb1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal87a58b477caf2639ca6da313d7b9beb1 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.table.col','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('ui.table.col'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>Year <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal87a58b477caf2639ca6da313d7b9beb1)): ?>
<?php $attributes = $__attributesOriginal87a58b477caf2639ca6da313d7b9beb1; ?>
<?php unset($__attributesOriginal87a58b477caf2639ca6da313d7b9beb1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal87a58b477caf2639ca6da313d7b9beb1)): ?>
<?php $component = $__componentOriginal87a58b477caf2639ca6da313d7b9beb1; ?>
<?php unset($__componentOriginal87a58b477caf2639ca6da313d7b9beb1); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginal87a58b477caf2639ca6da313d7b9beb1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal87a58b477caf2639ca6da313d7b9beb1 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.table.col','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('ui.table.col'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>Registration <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal87a58b477caf2639ca6da313d7b9beb1)): ?>
<?php $attributes = $__attributesOriginal87a58b477caf2639ca6da313d7b9beb1; ?>
<?php unset($__attributesOriginal87a58b477caf2639ca6da313d7b9beb1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal87a58b477caf2639ca6da313d7b9beb1)): ?>
<?php $component = $__componentOriginal87a58b477caf2639ca6da313d7b9beb1; ?>
<?php unset($__componentOriginal87a58b477caf2639ca6da313d7b9beb1); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginal87a58b477caf2639ca6da313d7b9beb1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal87a58b477caf2639ca6da313d7b9beb1 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.table.col','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('ui.table.col'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>Fuel Type <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal87a58b477caf2639ca6da313d7b9beb1)): ?>
<?php $attributes = $__attributesOriginal87a58b477caf2639ca6da313d7b9beb1; ?>
<?php unset($__attributesOriginal87a58b477caf2639ca6da313d7b9beb1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal87a58b477caf2639ca6da313d7b9beb1)): ?>
<?php $component = $__componentOriginal87a58b477caf2639ca6da313d7b9beb1; ?>
<?php unset($__componentOriginal87a58b477caf2639ca6da313d7b9beb1); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginal87a58b477caf2639ca6da313d7b9beb1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal87a58b477caf2639ca6da313d7b9beb1 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.table.col','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('ui.table.col'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>Body Type <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal87a58b477caf2639ca6da313d7b9beb1)): ?>
<?php $attributes = $__attributesOriginal87a58b477caf2639ca6da313d7b9beb1; ?>
<?php unset($__attributesOriginal87a58b477caf2639ca6da313d7b9beb1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal87a58b477caf2639ca6da313d7b9beb1)): ?>
<?php $component = $__componentOriginal87a58b477caf2639ca6da313d7b9beb1; ?>
<?php unset($__componentOriginal87a58b477caf2639ca6da313d7b9beb1); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginal87a58b477caf2639ca6da313d7b9beb1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal87a58b477caf2639ca6da313d7b9beb1 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.table.col','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('ui.table.col'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>Transmission Type <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal87a58b477caf2639ca6da313d7b9beb1)): ?>
<?php $attributes = $__attributesOriginal87a58b477caf2639ca6da313d7b9beb1; ?>
<?php unset($__attributesOriginal87a58b477caf2639ca6da313d7b9beb1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal87a58b477caf2639ca6da313d7b9beb1)): ?>
<?php $component = $__componentOriginal87a58b477caf2639ca6da313d7b9beb1; ?>
<?php unset($__componentOriginal87a58b477caf2639ca6da313d7b9beb1); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginal87a58b477caf2639ca6da313d7b9beb1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal87a58b477caf2639ca6da313d7b9beb1 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.table.col','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('ui.table.col'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>CC <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal87a58b477caf2639ca6da313d7b9beb1)): ?>
<?php $attributes = $__attributesOriginal87a58b477caf2639ca6da313d7b9beb1; ?>
<?php unset($__attributesOriginal87a58b477caf2639ca6da313d7b9beb1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal87a58b477caf2639ca6da313d7b9beb1)): ?>
<?php $component = $__componentOriginal87a58b477caf2639ca6da313d7b9beb1; ?>
<?php unset($__componentOriginal87a58b477caf2639ca6da313d7b9beb1); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginal87a58b477caf2639ca6da313d7b9beb1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal87a58b477caf2639ca6da313d7b9beb1 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.table.col','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('ui.table.col'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>No. Doors <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal87a58b477caf2639ca6da313d7b9beb1)): ?>
<?php $attributes = $__attributesOriginal87a58b477caf2639ca6da313d7b9beb1; ?>
<?php unset($__attributesOriginal87a58b477caf2639ca6da313d7b9beb1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal87a58b477caf2639ca6da313d7b9beb1)): ?>
<?php $component = $__componentOriginal87a58b477caf2639ca6da313d7b9beb1; ?>
<?php unset($__componentOriginal87a58b477caf2639ca6da313d7b9beb1); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginal87a58b477caf2639ca6da313d7b9beb1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal87a58b477caf2639ca6da313d7b9beb1 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.table.col','data' => ['class' => 'text-right']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('ui.table.col'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'text-right']); ?>Actions <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal87a58b477caf2639ca6da313d7b9beb1)): ?>
<?php $attributes = $__attributesOriginal87a58b477caf2639ca6da313d7b9beb1; ?>
<?php unset($__attributesOriginal87a58b477caf2639ca6da313d7b9beb1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal87a58b477caf2639ca6da313d7b9beb1)): ?>
<?php $component = $__componentOriginal87a58b477caf2639ca6da313d7b9beb1; ?>
<?php unset($__componentOriginal87a58b477caf2639ca6da313d7b9beb1); ?>
<?php endif; ?>
             <?php $__env->endSlot(); ?>

            <?php $__currentLoopData = $vehicles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vehicle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if (isset($component)) { $__componentOriginal904dd73f6ca4f8b6d85456c0929ab9fc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal904dd73f6ca4f8b6d85456c0929ab9fc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.table.row','data' => ['hover' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('ui.table.row'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['hover' => true]); ?>
                    <?php if (isset($component)) { $__componentOriginal498d816723d295cc3b24c2c8be07ff32 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal498d816723d295cc3b24c2c8be07ff32 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.table.cell','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('ui.table.cell'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?><?php echo e($vehicle->make); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal498d816723d295cc3b24c2c8be07ff32)): ?>
<?php $attributes = $__attributesOriginal498d816723d295cc3b24c2c8be07ff32; ?>
<?php unset($__attributesOriginal498d816723d295cc3b24c2c8be07ff32); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal498d816723d295cc3b24c2c8be07ff32)): ?>
<?php $component = $__componentOriginal498d816723d295cc3b24c2c8be07ff32; ?>
<?php unset($__componentOriginal498d816723d295cc3b24c2c8be07ff32); ?>
<?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginal498d816723d295cc3b24c2c8be07ff32 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal498d816723d295cc3b24c2c8be07ff32 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.table.cell','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('ui.table.cell'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?><?php echo e($vehicle->model); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal498d816723d295cc3b24c2c8be07ff32)): ?>
<?php $attributes = $__attributesOriginal498d816723d295cc3b24c2c8be07ff32; ?>
<?php unset($__attributesOriginal498d816723d295cc3b24c2c8be07ff32); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal498d816723d295cc3b24c2c8be07ff32)): ?>
<?php $component = $__componentOriginal498d816723d295cc3b24c2c8be07ff32; ?>
<?php unset($__componentOriginal498d816723d295cc3b24c2c8be07ff32); ?>
<?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginal498d816723d295cc3b24c2c8be07ff32 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal498d816723d295cc3b24c2c8be07ff32 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.table.cell','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('ui.table.cell'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?><?php echo e($vehicle->year); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal498d816723d295cc3b24c2c8be07ff32)): ?>
<?php $attributes = $__attributesOriginal498d816723d295cc3b24c2c8be07ff32; ?>
<?php unset($__attributesOriginal498d816723d295cc3b24c2c8be07ff32); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal498d816723d295cc3b24c2c8be07ff32)): ?>
<?php $component = $__componentOriginal498d816723d295cc3b24c2c8be07ff32; ?>
<?php unset($__componentOriginal498d816723d295cc3b24c2c8be07ff32); ?>
<?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginal498d816723d295cc3b24c2c8be07ff32 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal498d816723d295cc3b24c2c8be07ff32 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.table.cell','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('ui.table.cell'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?><?php echo e($vehicle->registration); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal498d816723d295cc3b24c2c8be07ff32)): ?>
<?php $attributes = $__attributesOriginal498d816723d295cc3b24c2c8be07ff32; ?>
<?php unset($__attributesOriginal498d816723d295cc3b24c2c8be07ff32); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal498d816723d295cc3b24c2c8be07ff32)): ?>
<?php $component = $__componentOriginal498d816723d295cc3b24c2c8be07ff32; ?>
<?php unset($__componentOriginal498d816723d295cc3b24c2c8be07ff32); ?>
<?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginal498d816723d295cc3b24c2c8be07ff32 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal498d816723d295cc3b24c2c8be07ff32 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.table.cell','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('ui.table.cell'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?><?php echo e($vehicle->fuel_type); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal498d816723d295cc3b24c2c8be07ff32)): ?>
<?php $attributes = $__attributesOriginal498d816723d295cc3b24c2c8be07ff32; ?>
<?php unset($__attributesOriginal498d816723d295cc3b24c2c8be07ff32); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal498d816723d295cc3b24c2c8be07ff32)): ?>
<?php $component = $__componentOriginal498d816723d295cc3b24c2c8be07ff32; ?>
<?php unset($__componentOriginal498d816723d295cc3b24c2c8be07ff32); ?>
<?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginal498d816723d295cc3b24c2c8be07ff32 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal498d816723d295cc3b24c2c8be07ff32 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.table.cell','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('ui.table.cell'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?><?php echo e($vehicle->body_type); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal498d816723d295cc3b24c2c8be07ff32)): ?>
<?php $attributes = $__attributesOriginal498d816723d295cc3b24c2c8be07ff32; ?>
<?php unset($__attributesOriginal498d816723d295cc3b24c2c8be07ff32); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal498d816723d295cc3b24c2c8be07ff32)): ?>
<?php $component = $__componentOriginal498d816723d295cc3b24c2c8be07ff32; ?>
<?php unset($__componentOriginal498d816723d295cc3b24c2c8be07ff32); ?>
<?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginal498d816723d295cc3b24c2c8be07ff32 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal498d816723d295cc3b24c2c8be07ff32 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.table.cell','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('ui.table.cell'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?><?php echo e($vehicle->transmission_type); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal498d816723d295cc3b24c2c8be07ff32)): ?>
<?php $attributes = $__attributesOriginal498d816723d295cc3b24c2c8be07ff32; ?>
<?php unset($__attributesOriginal498d816723d295cc3b24c2c8be07ff32); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal498d816723d295cc3b24c2c8be07ff32)): ?>
<?php $component = $__componentOriginal498d816723d295cc3b24c2c8be07ff32; ?>
<?php unset($__componentOriginal498d816723d295cc3b24c2c8be07ff32); ?>
<?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginal498d816723d295cc3b24c2c8be07ff32 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal498d816723d295cc3b24c2c8be07ff32 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.table.cell','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('ui.table.cell'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?><?php echo e($vehicle->cc); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal498d816723d295cc3b24c2c8be07ff32)): ?>
<?php $attributes = $__attributesOriginal498d816723d295cc3b24c2c8be07ff32; ?>
<?php unset($__attributesOriginal498d816723d295cc3b24c2c8be07ff32); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal498d816723d295cc3b24c2c8be07ff32)): ?>
<?php $component = $__componentOriginal498d816723d295cc3b24c2c8be07ff32; ?>
<?php unset($__componentOriginal498d816723d295cc3b24c2c8be07ff32); ?>
<?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginal498d816723d295cc3b24c2c8be07ff32 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal498d816723d295cc3b24c2c8be07ff32 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.table.cell','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('ui.table.cell'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?><?php echo e($vehicle->no_doors); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal498d816723d295cc3b24c2c8be07ff32)): ?>
<?php $attributes = $__attributesOriginal498d816723d295cc3b24c2c8be07ff32; ?>
<?php unset($__attributesOriginal498d816723d295cc3b24c2c8be07ff32); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal498d816723d295cc3b24c2c8be07ff32)): ?>
<?php $component = $__componentOriginal498d816723d295cc3b24c2c8be07ff32; ?>
<?php unset($__componentOriginal498d816723d295cc3b24c2c8be07ff32); ?>
<?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginal498d816723d295cc3b24c2c8be07ff32 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal498d816723d295cc3b24c2c8be07ff32 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.table.cell','data' => ['class' => 'flex justify-end text-right']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('ui.table.cell'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'flex justify-end text-right']); ?>
                        
                        <?php if (isset($component)) { $__componentOriginal606bedd6108050b8303bc7c381e2387c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal606bedd6108050b8303bc7c381e2387c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.link','data' => ['href' => ''.e(route('vehicles.edit', ['id' => $vehicle->id])).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('ui.link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => ''.e(route('vehicles.edit', ['id' => $vehicle->id])).'']); ?>
                            <?php if (isset($component)) { $__componentOriginal33345350c2b014c09378c729bb445d68 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal33345350c2b014c09378c729bb445d68 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.svg.edit','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('ui.svg.edit'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal33345350c2b014c09378c729bb445d68)): ?>
<?php $attributes = $__attributesOriginal33345350c2b014c09378c729bb445d68; ?>
<?php unset($__attributesOriginal33345350c2b014c09378c729bb445d68); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal33345350c2b014c09378c729bb445d68)): ?>
<?php $component = $__componentOriginal33345350c2b014c09378c729bb445d68; ?>
<?php unset($__componentOriginal33345350c2b014c09378c729bb445d68); ?>
<?php endif; ?>
                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal606bedd6108050b8303bc7c381e2387c)): ?>
<?php $attributes = $__attributesOriginal606bedd6108050b8303bc7c381e2387c; ?>
<?php unset($__attributesOriginal606bedd6108050b8303bc7c381e2387c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal606bedd6108050b8303bc7c381e2387c)): ?>
<?php $component = $__componentOriginal606bedd6108050b8303bc7c381e2387c; ?>
<?php unset($__componentOriginal606bedd6108050b8303bc7c381e2387c); ?>
<?php endif; ?>

                        <?php if (isset($component)) { $__componentOriginal606bedd6108050b8303bc7c381e2387c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal606bedd6108050b8303bc7c381e2387c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.link','data' => ['href' => ''.e(route('vehicles.show', ['id' => $vehicle->id])).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('ui.link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => ''.e(route('vehicles.show', ['id' => $vehicle->id])).'']); ?>
                            <?php if (isset($component)) { $__componentOriginal42108e9215d2c9dfbafa3d2ecf252f4f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal42108e9215d2c9dfbafa3d2ecf252f4f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.svg.eye','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('ui.svg.eye'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal42108e9215d2c9dfbafa3d2ecf252f4f)): ?>
<?php $attributes = $__attributesOriginal42108e9215d2c9dfbafa3d2ecf252f4f; ?>
<?php unset($__attributesOriginal42108e9215d2c9dfbafa3d2ecf252f4f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal42108e9215d2c9dfbafa3d2ecf252f4f)): ?>
<?php $component = $__componentOriginal42108e9215d2c9dfbafa3d2ecf252f4f; ?>
<?php unset($__componentOriginal42108e9215d2c9dfbafa3d2ecf252f4f); ?>
<?php endif; ?>
                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal606bedd6108050b8303bc7c381e2387c)): ?>
<?php $attributes = $__attributesOriginal606bedd6108050b8303bc7c381e2387c; ?>
<?php unset($__attributesOriginal606bedd6108050b8303bc7c381e2387c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal606bedd6108050b8303bc7c381e2387c)): ?>
<?php $component = $__componentOriginal606bedd6108050b8303bc7c381e2387c; ?>
<?php unset($__componentOriginal606bedd6108050b8303bc7c381e2387c); ?>
<?php endif; ?>
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal498d816723d295cc3b24c2c8be07ff32)): ?>
<?php $attributes = $__attributesOriginal498d816723d295cc3b24c2c8be07ff32; ?>
<?php unset($__attributesOriginal498d816723d295cc3b24c2c8be07ff32); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal498d816723d295cc3b24c2c8be07ff32)): ?>
<?php $component = $__componentOriginal498d816723d295cc3b24c2c8be07ff32; ?>
<?php unset($__componentOriginal498d816723d295cc3b24c2c8be07ff32); ?>
<?php endif; ?>
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal904dd73f6ca4f8b6d85456c0929ab9fc)): ?>
<?php $attributes = $__attributesOriginal904dd73f6ca4f8b6d85456c0929ab9fc; ?>
<?php unset($__attributesOriginal904dd73f6ca4f8b6d85456c0929ab9fc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal904dd73f6ca4f8b6d85456c0929ab9fc)): ?>
<?php $component = $__componentOriginal904dd73f6ca4f8b6d85456c0929ab9fc; ?>
<?php unset($__componentOriginal904dd73f6ca4f8b6d85456c0929ab9fc); ?>
<?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal793d2b22631f88b8a3d00569a12acf88)): ?>
<?php $attributes = $__attributesOriginal793d2b22631f88b8a3d00569a12acf88; ?>
<?php unset($__attributesOriginal793d2b22631f88b8a3d00569a12acf88); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal793d2b22631f88b8a3d00569a12acf88)): ?>
<?php $component = $__componentOriginal793d2b22631f88b8a3d00569a12acf88; ?>
<?php unset($__componentOriginal793d2b22631f88b8a3d00569a12acf88); ?>
<?php endif; ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldae4cd48acb67888a4631e1ba48f2f93)): ?>
<?php $attributes = $__attributesOriginaldae4cd48acb67888a4631e1ba48f2f93; ?>
<?php unset($__attributesOriginaldae4cd48acb67888a4631e1ba48f2f93); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldae4cd48acb67888a4631e1ba48f2f93)): ?>
<?php $component = $__componentOriginaldae4cd48acb67888a4631e1ba48f2f93; ?>
<?php unset($__componentOriginaldae4cd48acb67888a4631e1ba48f2f93); ?>
<?php endif; ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $attributes = $__attributesOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__attributesOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php /**PATH C:\Users\connor\Desktop\CarLooker\resources\views/vehicle/index.blade.php ENDPATH**/ ?>