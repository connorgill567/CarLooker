<div class="flex justify-between items-baseline border-b border-gray-700 pb-1 my-5">   
    <?php echo e($slot); ?>

</div>



<?php /**PATH C:\Users\connor\Desktop\CarLooker\resources\views/components/ui/header.blade.php ENDPATH**/ ?>