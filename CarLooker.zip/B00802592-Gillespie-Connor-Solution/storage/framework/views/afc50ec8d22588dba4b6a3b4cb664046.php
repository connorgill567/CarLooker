<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps([
   'label' => null,
   'name',
   'value'   
]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps([
   'label' => null,
   'name',
   'value'   
]); ?>
<?php foreach (array_filter(([
   'label' => null,
   'name',
   'value'   
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
 
<div>
    <?php if(isset($label)): ?>
        <label for="<?php echo e($name); ?>" class="mb-2 block text-gray-700 text-sm font-bold uppercase">
            <?php echo e($label); ?>

        </label>
    <?php endif; ?>

    <input id="<?php echo e($name); ?>" name="<?php echo e($name); ?>" value="<?php echo e($value); ?>" 
    <?php echo e($attributes->merge(['class'=>'border rounded-md w-full p-2.5 text-gray-700 leading-tight focus:ring-blue-500 focus:border-blue-500 '])); ?>>

    <?php $__errorArgs = [$name];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div class="text-sm text-red-500 mt-2"> 
            <?php echo e($message); ?> 
        </div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> 
</div> 
<?php /**PATH C:\Users\conno\Downloads\practical8\resources\views/components/ui/form/input.blade.php ENDPATH**/ ?>