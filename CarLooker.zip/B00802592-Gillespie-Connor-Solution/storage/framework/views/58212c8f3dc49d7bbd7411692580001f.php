<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23a33f287873b564aaf305a1526eada4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="container mx-auto py-10">
        <h1 class="text-4xl font-bold mb-6 text-gray-800">About CarLooker</h1>

        <div class="bg-white rounded-lg shadow-lg p-6 mb-8">
            <p class="text-xl text-gray-700 mb-4">Welcome to CarLooker, the ultimate vehicle management system designed for car enthusiasts like you.</p>
            
            <p class="text-lg text-gray-600 mb-6">At CarLooker, we understand your passion for cars and the importance of keeping track of your prized possessions. Our platform provides a comprehensive solution to manage your vehicle collection, whether you own classic cars, sports cars, or everyday vehicles.</p>
            
            <p class="text-lg text-gray-600 mb-6">With CarLooker, you can easily store and access detailed information about each vehicle in your collection, including make, model, year, registration, fuel type, body type, transmission type, engine size, and more. Our intuitive interface makes it effortless to add, edit, and view your vehicles' details.</p>
            
            <p class="text-lg text-gray-600">CarLooker is built using cutting-edge technologies to ensure a seamless and efficient user experience:</p>
        </div>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $attributes = $__attributesOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__attributesOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?><?php /**PATH C:\Users\conno\CarLooker\resources\views/about.blade.php ENDPATH**/ ?>