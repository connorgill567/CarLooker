<?php if (isset($component)) { $__componentOriginaldae4cd48acb67888a4631e1ba48f2f93 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldae4cd48acb67888a4631e1ba48f2f93 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.card','data' => ['class' => 'mt-5']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('ui.card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mt-5']); ?>
    <!-- tbc add a card title to include title and link to navigate back to book -->
    <!-- tbc review page header component usage for guidance -->
     <?php $__env->slot('header', null, ['class' => 'flex gap-2 items-center justify-between']); ?> 
        <h2 class="text-2xl font-bold">Reviews</h2>
        <!-- TBC Q3 - authorise -->
        <?php if (isset($component)) { $__componentOriginal606bedd6108050b8303bc7c381e2387c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal606bedd6108050b8303bc7c381e2387c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.link','data' => ['class' => 'flex gap-1','href' => ''.e(route('reviews.create', ['id'=>$book->id])).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('ui.link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'flex gap-1','href' => ''.e(route('reviews.create', ['id'=>$book->id])).'']); ?>
            <?php if (isset($component)) { $__componentOriginalb5db7d2d83fbf184201a490bdea0d7da = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb5db7d2d83fbf184201a490bdea0d7da = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.svg.plus','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('ui.svg.plus'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb5db7d2d83fbf184201a490bdea0d7da)): ?>
<?php $attributes = $__attributesOriginalb5db7d2d83fbf184201a490bdea0d7da; ?>
<?php unset($__attributesOriginalb5db7d2d83fbf184201a490bdea0d7da); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb5db7d2d83fbf184201a490bdea0d7da)): ?>
<?php $component = $__componentOriginalb5db7d2d83fbf184201a490bdea0d7da; ?>
<?php unset($__componentOriginalb5db7d2d83fbf184201a490bdea0d7da); ?>
<?php endif; ?>
            <span>Add</span> 
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal606bedd6108050b8303bc7c381e2387c)): ?>
<?php $attributes = $__attributesOriginal606bedd6108050b8303bc7c381e2387c; ?>
<?php unset($__attributesOriginal606bedd6108050b8303bc7c381e2387c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal606bedd6108050b8303bc7c381e2387c)): ?>
<?php $component = $__componentOriginal606bedd6108050b8303bc7c381e2387c; ?>
<?php unset($__componentOriginal606bedd6108050b8303bc7c381e2387c); ?>
<?php endif; ?>
    
     <?php $__env->endSlot(); ?>


    <?php if (isset($component)) { $__componentOriginal793d2b22631f88b8a3d00569a12acf88 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal793d2b22631f88b8a3d00569a12acf88 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.table.index','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('ui.table'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
         <?php $__env->slot('head', null, []); ?> 
            <?php if (isset($component)) { $__componentOriginal87a58b477caf2639ca6da313d7b9beb1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal87a58b477caf2639ca6da313d7b9beb1 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.table.col','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('ui.table.col'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>Name <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal87a58b477caf2639ca6da313d7b9beb1)): ?>
<?php $attributes = $__attributesOriginal87a58b477caf2639ca6da313d7b9beb1; ?>
<?php unset($__attributesOriginal87a58b477caf2639ca6da313d7b9beb1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal87a58b477caf2639ca6da313d7b9beb1)): ?>
<?php $component = $__componentOriginal87a58b477caf2639ca6da313d7b9beb1; ?>
<?php unset($__componentOriginal87a58b477caf2639ca6da313d7b9beb1); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginal87a58b477caf2639ca6da313d7b9beb1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal87a58b477caf2639ca6da313d7b9beb1 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.table.col','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('ui.table.col'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>Rate <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal87a58b477caf2639ca6da313d7b9beb1)): ?>
<?php $attributes = $__attributesOriginal87a58b477caf2639ca6da313d7b9beb1; ?>
<?php unset($__attributesOriginal87a58b477caf2639ca6da313d7b9beb1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal87a58b477caf2639ca6da313d7b9beb1)): ?>
<?php $component = $__componentOriginal87a58b477caf2639ca6da313d7b9beb1; ?>
<?php unset($__componentOriginal87a58b477caf2639ca6da313d7b9beb1); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginal87a58b477caf2639ca6da313d7b9beb1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal87a58b477caf2639ca6da313d7b9beb1 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.table.col','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('ui.table.col'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>Reviewed <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal87a58b477caf2639ca6da313d7b9beb1)): ?>
<?php $attributes = $__attributesOriginal87a58b477caf2639ca6da313d7b9beb1; ?>
<?php unset($__attributesOriginal87a58b477caf2639ca6da313d7b9beb1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal87a58b477caf2639ca6da313d7b9beb1)): ?>
<?php $component = $__componentOriginal87a58b477caf2639ca6da313d7b9beb1; ?>
<?php unset($__componentOriginal87a58b477caf2639ca6da313d7b9beb1); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginal87a58b477caf2639ca6da313d7b9beb1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal87a58b477caf2639ca6da313d7b9beb1 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.table.col','data' => ['class' => 'text-right']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('ui.table.col'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'text-right']); ?>Actions <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal87a58b477caf2639ca6da313d7b9beb1)): ?>
<?php $attributes = $__attributesOriginal87a58b477caf2639ca6da313d7b9beb1; ?>
<?php unset($__attributesOriginal87a58b477caf2639ca6da313d7b9beb1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal87a58b477caf2639ca6da313d7b9beb1)): ?>
<?php $component = $__componentOriginal87a58b477caf2639ca6da313d7b9beb1; ?>
<?php unset($__componentOriginal87a58b477caf2639ca6da313d7b9beb1); ?>
<?php endif; ?>
         <?php $__env->endSlot(); ?>
    
        <?php $__currentLoopData = $book->reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if (isset($component)) { $__componentOriginal904dd73f6ca4f8b6d85456c0929ab9fc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal904dd73f6ca4f8b6d85456c0929ab9fc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.table.row','data' => ['hover' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('ui.table.row'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['hover' => true]); ?>
                <?php if (isset($component)) { $__componentOriginal498d816723d295cc3b24c2c8be07ff32 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal498d816723d295cc3b24c2c8be07ff32 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.table.cell','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('ui.table.cell'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?><?php echo e($review->name); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal498d816723d295cc3b24c2c8be07ff32)): ?>
<?php $attributes = $__attributesOriginal498d816723d295cc3b24c2c8be07ff32; ?>
<?php unset($__attributesOriginal498d816723d295cc3b24c2c8be07ff32); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal498d816723d295cc3b24c2c8be07ff32)): ?>
<?php $component = $__componentOriginal498d816723d295cc3b24c2c8be07ff32; ?>
<?php unset($__componentOriginal498d816723d295cc3b24c2c8be07ff32); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginal498d816723d295cc3b24c2c8be07ff32 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal498d816723d295cc3b24c2c8be07ff32 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.table.cell','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('ui.table.cell'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?><?php echo e($review->rating); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal498d816723d295cc3b24c2c8be07ff32)): ?>
<?php $attributes = $__attributesOriginal498d816723d295cc3b24c2c8be07ff32; ?>
<?php unset($__attributesOriginal498d816723d295cc3b24c2c8be07ff32); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal498d816723d295cc3b24c2c8be07ff32)): ?>
<?php $component = $__componentOriginal498d816723d295cc3b24c2c8be07ff32; ?>
<?php unset($__componentOriginal498d816723d295cc3b24c2c8be07ff32); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginal498d816723d295cc3b24c2c8be07ff32 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal498d816723d295cc3b24c2c8be07ff32 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.table.cell','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('ui.table.cell'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?><?php echo e($review->reviewed_on_for_humans); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal498d816723d295cc3b24c2c8be07ff32)): ?>
<?php $attributes = $__attributesOriginal498d816723d295cc3b24c2c8be07ff32; ?>
<?php unset($__attributesOriginal498d816723d295cc3b24c2c8be07ff32); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal498d816723d295cc3b24c2c8be07ff32)): ?>
<?php $component = $__componentOriginal498d816723d295cc3b24c2c8be07ff32; ?>
<?php unset($__componentOriginal498d816723d295cc3b24c2c8be07ff32); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginal498d816723d295cc3b24c2c8be07ff32 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal498d816723d295cc3b24c2c8be07ff32 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.table.cell','data' => ['class' => 'text-right']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('ui.table.cell'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'text-right']); ?>
                    <?php if (isset($component)) { $__componentOriginal606bedd6108050b8303bc7c381e2387c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal606bedd6108050b8303bc7c381e2387c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.link','data' => ['href' => ''.e(route('reviews.show',['id'=>$review->id])).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('ui.link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => ''.e(route('reviews.show',['id'=>$review->id])).'']); ?>
                        View
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal606bedd6108050b8303bc7c381e2387c)): ?>
<?php $attributes = $__attributesOriginal606bedd6108050b8303bc7c381e2387c; ?>
<?php unset($__attributesOriginal606bedd6108050b8303bc7c381e2387c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal606bedd6108050b8303bc7c381e2387c)): ?>
<?php $component = $__componentOriginal606bedd6108050b8303bc7c381e2387c; ?>
<?php unset($__componentOriginal606bedd6108050b8303bc7c381e2387c); ?>
<?php endif; ?>          
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal498d816723d295cc3b24c2c8be07ff32)): ?>
<?php $attributes = $__attributesOriginal498d816723d295cc3b24c2c8be07ff32; ?>
<?php unset($__attributesOriginal498d816723d295cc3b24c2c8be07ff32); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal498d816723d295cc3b24c2c8be07ff32)): ?>
<?php $component = $__componentOriginal498d816723d295cc3b24c2c8be07ff32; ?>
<?php unset($__componentOriginal498d816723d295cc3b24c2c8be07ff32); ?>
<?php endif; ?>           
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal904dd73f6ca4f8b6d85456c0929ab9fc)): ?>
<?php $attributes = $__attributesOriginal904dd73f6ca4f8b6d85456c0929ab9fc; ?>
<?php unset($__attributesOriginal904dd73f6ca4f8b6d85456c0929ab9fc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal904dd73f6ca4f8b6d85456c0929ab9fc)): ?>
<?php $component = $__componentOriginal904dd73f6ca4f8b6d85456c0929ab9fc; ?>
<?php unset($__componentOriginal904dd73f6ca4f8b6d85456c0929ab9fc); ?>
<?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal793d2b22631f88b8a3d00569a12acf88)): ?>
<?php $attributes = $__attributesOriginal793d2b22631f88b8a3d00569a12acf88; ?>
<?php unset($__attributesOriginal793d2b22631f88b8a3d00569a12acf88); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal793d2b22631f88b8a3d00569a12acf88)): ?>
<?php $component = $__componentOriginal793d2b22631f88b8a3d00569a12acf88; ?>
<?php unset($__componentOriginal793d2b22631f88b8a3d00569a12acf88); ?>
<?php endif; ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldae4cd48acb67888a4631e1ba48f2f93)): ?>
<?php $attributes = $__attributesOriginaldae4cd48acb67888a4631e1ba48f2f93; ?>
<?php unset($__attributesOriginaldae4cd48acb67888a4631e1ba48f2f93); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldae4cd48acb67888a4631e1ba48f2f93)): ?>
<?php $component = $__componentOriginaldae4cd48acb67888a4631e1ba48f2f93; ?>
<?php unset($__componentOriginaldae4cd48acb67888a4631e1ba48f2f93); ?>
<?php endif; ?>
 
       <?php /**PATH C:\Users\conno\Downloads\practical8\resources\views/book/_reviews.blade.php ENDPATH**/ ?>