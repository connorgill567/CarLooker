<div <?php echo e($attributes->merge(['class' => "bg-white shadow-md rounded-lg overflow-hidden"])); ?>>
    <?php if(isset($header)): ?>
        <div <?php echo e($header->attributes->merge(['class' => "px-6 py-4 bg-gray-100 border-b border-gray-200"])); ?>>
            <?php echo e($header); ?>

        </div>
    <?php endif; ?>

    <div class="p-6">
        <?php echo e($slot); ?>

    </div>

    <?php if(isset($footer)): ?>
        <div <?php echo e($footer->attributes->merge(['class' => "px-6 py-4 bg-gray-100 border-t border-gray-200"])); ?>>
            <?php echo e($footer); ?>

        </div>
    <?php endif; ?>
</div>
<?php /**PATH C:\Users\conno\CarLooker\resources\views/components/ui/card.blade.php ENDPATH**/ ?>