<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['variant' => 'blue']) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['variant' => 'blue']); ?>
<?php foreach (array_filter((['variant' => 'blue']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<?php
$classes = match($variant) {
   'blue'   => "py-2 px-4 text-sm font-medium rounded-lg text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500",
   'red'    => "py-2 px-4 text-sm font-medium rounded-lg text-white bg-red-600 hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-red-500",
   'green'  => "py-2 px-4 text-sm font-medium rounded-lg text-white bg-green-600 hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-green-500",
   'yellow' => "py-2 px-4 text-sm font-medium rounded-lg text-white bg-yellow-500 hover:bg-yellow-600 focus:outline-none focus:ring-2 focus:ring-yellow-400",
   'dark'   => "py-2 px-4 text-sm font-medium rounded-lg text-white bg-gray-800 hover:bg-gray-900 focus:outline-none focus:ring-2 focus:ring-gray-700",
   'light'  => "py-2 px-4 text-sm font-medium rounded-lg text-gray-900 bg-white border border-gray-200 hover:bg-gray-100 hover:text-blue-700 focus:outline-none focus:ring-2 focus:ring-gray-200",
   'link'   => "py-2 px-4 text-sm font-medium text-blue-600 hover:text-blue-800 hover:underline focus:outline-none",
   default  => "",
};
?>

<button <?php echo e($attributes->merge(["class" => $classes  ])); ?> >
   <?php echo e($slot); ?>

</button>
<?php /**PATH C:\Users\conno\CarLooker\resources\views/components/ui/button.blade.php ENDPATH**/ ?>