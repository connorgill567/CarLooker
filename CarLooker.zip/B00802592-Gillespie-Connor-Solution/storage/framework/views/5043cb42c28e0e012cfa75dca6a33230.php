<!-- Title -->
<div class="mt-2">
    <?php if (isset($component)) { $__componentOriginalc3af3653dc31a14448cdb0b348832110 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc3af3653dc31a14448cdb0b348832110 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.form.input','data' => ['label' => 'Title','name' => 'title','value' => ''.e(old('title',$book->title)).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('ui.form.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Title','name' => 'title','value' => ''.e(old('title',$book->title)).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc3af3653dc31a14448cdb0b348832110)): ?>
<?php $attributes = $__attributesOriginalc3af3653dc31a14448cdb0b348832110; ?>
<?php unset($__attributesOriginalc3af3653dc31a14448cdb0b348832110); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc3af3653dc31a14448cdb0b348832110)): ?>
<?php $component = $__componentOriginalc3af3653dc31a14448cdb0b348832110; ?>
<?php unset($__componentOriginalc3af3653dc31a14448cdb0b348832110); ?>
<?php endif; ?>
</div>

<!-- Author --> 
<div class="mt-2">
    <?php if (isset($component)) { $__componentOriginalc3af3653dc31a14448cdb0b348832110 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc3af3653dc31a14448cdb0b348832110 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.form.input','data' => ['label' => 'Author','name' => 'author','value' => ''.e(old('author',$book->author)).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('ui.form.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Author','name' => 'author','value' => ''.e(old('author',$book->author)).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc3af3653dc31a14448cdb0b348832110)): ?>
<?php $attributes = $__attributesOriginalc3af3653dc31a14448cdb0b348832110; ?>
<?php unset($__attributesOriginalc3af3653dc31a14448cdb0b348832110); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc3af3653dc31a14448cdb0b348832110)): ?>
<?php $component = $__componentOriginalc3af3653dc31a14448cdb0b348832110; ?>
<?php unset($__componentOriginalc3af3653dc31a14448cdb0b348832110); ?>
<?php endif; ?> 
</div>

<div class="mt-2">
    <?php if (isset($component)) { $__componentOriginal3d764d9aa1637ee21fbd47e006854817 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3d764d9aa1637ee21fbd47e006854817 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.form.select','data' => ['label' => 'Category','options' => $categories,'name' => 'category_id','value' => ''.e(old('category_id',$book->category_id)).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('ui.form.select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Category','options' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($categories),'name' => 'category_id','value' => ''.e(old('category_id',$book->category_id)).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3d764d9aa1637ee21fbd47e006854817)): ?>
<?php $attributes = $__attributesOriginal3d764d9aa1637ee21fbd47e006854817; ?>
<?php unset($__attributesOriginal3d764d9aa1637ee21fbd47e006854817); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3d764d9aa1637ee21fbd47e006854817)): ?>
<?php $component = $__componentOriginal3d764d9aa1637ee21fbd47e006854817; ?>
<?php unset($__componentOriginal3d764d9aa1637ee21fbd47e006854817); ?>
<?php endif; ?>
</div>

<!-- Year and Rating -->
<div class="flex flex-row gap-4"> 
    <div class="mt-2 flex-1">
        <?php if (isset($component)) { $__componentOriginalc3af3653dc31a14448cdb0b348832110 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc3af3653dc31a14448cdb0b348832110 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.form.input','data' => ['label' => 'Year','name' => 'year','type' => 'number','value' => ''.e(old('year',$book->year)).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('ui.form.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Year','name' => 'year','type' => 'number','value' => ''.e(old('year',$book->year)).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc3af3653dc31a14448cdb0b348832110)): ?>
<?php $attributes = $__attributesOriginalc3af3653dc31a14448cdb0b348832110; ?>
<?php unset($__attributesOriginalc3af3653dc31a14448cdb0b348832110); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc3af3653dc31a14448cdb0b348832110)): ?>
<?php $component = $__componentOriginalc3af3653dc31a14448cdb0b348832110; ?>
<?php unset($__componentOriginalc3af3653dc31a14448cdb0b348832110); ?>
<?php endif; ?> 
    </div>

    <div class="mt-2 flex-1">
        <?php if (isset($component)) { $__componentOriginalc3af3653dc31a14448cdb0b348832110 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc3af3653dc31a14448cdb0b348832110 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.form.input','data' => ['label' => 'Rating','name' => 'rating','type' => 'number','value' => ''.e(old('rating',$book->rating)).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('ui.form.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Rating','name' => 'rating','type' => 'number','value' => ''.e(old('rating',$book->rating)).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc3af3653dc31a14448cdb0b348832110)): ?>
<?php $attributes = $__attributesOriginalc3af3653dc31a14448cdb0b348832110; ?>
<?php unset($__attributesOriginalc3af3653dc31a14448cdb0b348832110); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc3af3653dc31a14448cdb0b348832110)): ?>
<?php $component = $__componentOriginalc3af3653dc31a14448cdb0b348832110; ?>
<?php unset($__componentOriginalc3af3653dc31a14448cdb0b348832110); ?>
<?php endif; ?>
    </div>
</div>

<!-- Description -->
<div class="mt-2">
    <?php if (isset($component)) { $__componentOriginal6533f4949bed0869bfc088e9a22e363b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6533f4949bed0869bfc088e9a22e363b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.form.textarea','data' => ['label' => 'Description','name' => 'description','rows' => '8','value' => ''.e(old('description',$book->description)).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('ui.form.textarea'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Description','name' => 'description','rows' => '8','value' => ''.e(old('description',$book->description)).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6533f4949bed0869bfc088e9a22e363b)): ?>
<?php $attributes = $__attributesOriginal6533f4949bed0869bfc088e9a22e363b; ?>
<?php unset($__attributesOriginal6533f4949bed0869bfc088e9a22e363b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6533f4949bed0869bfc088e9a22e363b)): ?>
<?php $component = $__componentOriginal6533f4949bed0869bfc088e9a22e363b; ?>
<?php unset($__componentOriginal6533f4949bed0869bfc088e9a22e363b); ?>
<?php endif; ?>
</div><?php /**PATH C:\Users\conno\Downloads\practical8\resources\views/book/_inputs.blade.php ENDPATH**/ ?>