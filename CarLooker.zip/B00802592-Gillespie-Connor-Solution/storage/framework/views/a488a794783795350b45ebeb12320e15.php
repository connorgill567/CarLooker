<nav <?php echo e($attributes->merge(["class" => "flex gap-6 bg-gray-50 px-4 py-3 border-b"])); ?>>  
 <?php echo e($slot); ?>

</nav><?php /**PATH C:\Users\connor\Desktop\CarLooker\resources\views/components/ui/nav/index.blade.php ENDPATH**/ ?>