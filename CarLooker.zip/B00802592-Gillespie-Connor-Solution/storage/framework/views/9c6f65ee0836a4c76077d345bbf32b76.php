<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo e($title ?? 'CarLooker'); ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js"></script>
</head>

<body class="flex flex-col min-h-screen bg-gray-100">

    <!-- navbar -->
    <header class="bg-gray-900">
        <?php if (isset($component)) { $__componentOriginalb55e525bcf4e336a3dc267e7f66aa1e0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb55e525bcf4e336a3dc267e7f66aa1e0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.nav.index','data' => ['class' => 'justify-between items-center']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('ui.nav'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'justify-between items-center']); ?>
            <!-- main menu options -->
            <div class="flex items-center gap-6">
                <a href="/">
                    <img src="images/CarLookerLogo.webp" class="h-20 rounded-full transform hover:scale-110 transition-transform duration-300" alt="Website Logo">
                </a>
                <?php if (isset($component)) { $__componentOriginala7126f5d2314ae77706c18dfdafd2a54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala7126f5d2314ae77706c18dfdafd2a54 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.nav.link','data' => ['href' => ''.e(route('home')).'','class' => 'text-black text-lg font-semibold hover:text-blue-300']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('ui.nav.link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => ''.e(route('home')).'','class' => 'text-black text-lg font-semibold hover:text-blue-300']); ?>Home <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala7126f5d2314ae77706c18dfdafd2a54)): ?>
<?php $attributes = $__attributesOriginala7126f5d2314ae77706c18dfdafd2a54; ?>
<?php unset($__attributesOriginala7126f5d2314ae77706c18dfdafd2a54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala7126f5d2314ae77706c18dfdafd2a54)): ?>
<?php $component = $__componentOriginala7126f5d2314ae77706c18dfdafd2a54; ?>
<?php unset($__componentOriginala7126f5d2314ae77706c18dfdafd2a54); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginala7126f5d2314ae77706c18dfdafd2a54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala7126f5d2314ae77706c18dfdafd2a54 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.nav.link','data' => ['href' => ''.e(route('about')).'','class' => 'text-black text-lg font-semibold hover:text-blue-300']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('ui.nav.link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => ''.e(route('about')).'','class' => 'text-black text-lg font-semibold hover:text-blue-300']); ?>About <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala7126f5d2314ae77706c18dfdafd2a54)): ?>
<?php $attributes = $__attributesOriginala7126f5d2314ae77706c18dfdafd2a54; ?>
<?php unset($__attributesOriginala7126f5d2314ae77706c18dfdafd2a54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala7126f5d2314ae77706c18dfdafd2a54)): ?>
<?php $component = $__componentOriginala7126f5d2314ae77706c18dfdafd2a54; ?>
<?php unset($__componentOriginala7126f5d2314ae77706c18dfdafd2a54); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginala7126f5d2314ae77706c18dfdafd2a54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala7126f5d2314ae77706c18dfdafd2a54 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.nav.link','data' => ['href' => ''.e(route('contact')).'','class' => 'text-black text-lg font-semibold hover:text-blue-300']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('ui.nav.link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => ''.e(route('contact')).'','class' => 'text-black text-lg font-semibold hover:text-blue-300']); ?>Contact us <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala7126f5d2314ae77706c18dfdafd2a54)): ?>
<?php $attributes = $__attributesOriginala7126f5d2314ae77706c18dfdafd2a54; ?>
<?php unset($__attributesOriginala7126f5d2314ae77706c18dfdafd2a54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala7126f5d2314ae77706c18dfdafd2a54)): ?>
<?php $component = $__componentOriginala7126f5d2314ae77706c18dfdafd2a54; ?>
<?php unset($__componentOriginala7126f5d2314ae77706c18dfdafd2a54); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginala7126f5d2314ae77706c18dfdafd2a54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala7126f5d2314ae77706c18dfdafd2a54 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.nav.link','data' => ['href' => ''.e(route('vehicles.index')).'','class' => 'text-black text-lg font-semibold hover:text-blue-300']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('ui.nav.link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => ''.e(route('vehicles.index')).'','class' => 'text-black text-lg font-semibold hover:text-blue-300']); ?>Cars <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala7126f5d2314ae77706c18dfdafd2a54)): ?>
<?php $attributes = $__attributesOriginala7126f5d2314ae77706c18dfdafd2a54; ?>
<?php unset($__attributesOriginala7126f5d2314ae77706c18dfdafd2a54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala7126f5d2314ae77706c18dfdafd2a54)): ?>
<?php $component = $__componentOriginala7126f5d2314ae77706c18dfdafd2a54; ?>
<?php unset($__componentOriginala7126f5d2314ae77706c18dfdafd2a54); ?>
<?php endif; ?>
            </div>

            <!-- login/register/logout menu options -->
            <?php if (isset($component)) { $__componentOriginal42b5448ee9826668fd44b241e0c05b02 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal42b5448ee9826668fd44b241e0c05b02 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.auth.identity','data' => ['class' => 'text-white text-lg font-semibold']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('ui.auth.identity'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'text-white text-lg font-semibold']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal42b5448ee9826668fd44b241e0c05b02)): ?>
<?php $attributes = $__attributesOriginal42b5448ee9826668fd44b241e0c05b02; ?>
<?php unset($__attributesOriginal42b5448ee9826668fd44b241e0c05b02); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal42b5448ee9826668fd44b241e0c05b02)): ?>
<?php $component = $__componentOriginal42b5448ee9826668fd44b241e0c05b02; ?>
<?php unset($__componentOriginal42b5448ee9826668fd44b241e0c05b02); ?>
<?php endif; ?>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb55e525bcf4e336a3dc267e7f66aa1e0)): ?>
<?php $attributes = $__attributesOriginalb55e525bcf4e336a3dc267e7f66aa1e0; ?>
<?php unset($__attributesOriginalb55e525bcf4e336a3dc267e7f66aa1e0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb55e525bcf4e336a3dc267e7f66aa1e0)): ?>
<?php $component = $__componentOriginalb55e525bcf4e336a3dc267e7f66aa1e0; ?>
<?php unset($__componentOriginalb55e525bcf4e336a3dc267e7f66aa1e0); ?>
<?php endif; ?>
    </header>

    <!-- display flash message -->
    <?php if (isset($component)) { $__componentOriginalfc2c53cdc76e51152b8f2296be83e0da = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalfc2c53cdc76e51152b8f2296be83e0da = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.flash','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('ui.flash'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalfc2c53cdc76e51152b8f2296be83e0da)): ?>
<?php $attributes = $__attributesOriginalfc2c53cdc76e51152b8f2296be83e0da; ?>
<?php unset($__attributesOriginalfc2c53cdc76e51152b8f2296be83e0da); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalfc2c53cdc76e51152b8f2296be83e0da)): ?>
<?php $component = $__componentOriginalfc2c53cdc76e51152b8f2296be83e0da; ?>
<?php unset($__componentOriginalfc2c53cdc76e51152b8f2296be83e0da); ?>
<?php endif; ?>

    <!-- main page slot -->
    <main class="container mx-auto my-8 flex-auto">
        <?php echo e($slot); ?>

    </main>

    <!-- footer -->
    <footer class="bg-gray-900 text-white px-4 py-6 text-center">
        <div class="flex flex-col items-center gap-4">
            <div class="text-lg font-semibold">Copyright @ <?php echo e(date("Y")); ?> CarLooker</div>
            
        </div>
    </footer>
</body>
</html><?php /**PATH C:\Users\connor\Desktop\CarLooker\resources\views/components/layout.blade.php ENDPATH**/ ?>