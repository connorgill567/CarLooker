<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps([
    'crumbs' => []
]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps([
    'crumbs' => []
]); ?>
<?php foreach (array_filter(([
    'crumbs' => []
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<!-- Breadcrumb -->
<nav <?php echo e($attributes->merge(['class'=> "text-sm font-medium px-5 py-3 w-full text-gray-200 border border-gray-200 rounded-lg bg-gray-100 text-gray-900"])); ?> aria-label="Breadcrumb">
    <ol class="inline-flex items-center space-x-1">
        <?php $__currentLoopData = $crumbs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $name => $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="inline-flex items-center gap-2">
                <?php if($loop->first): ?>
                    <svg class="w-4 h-4" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path d="M10.707 2.293a1 1 0 00-1.414 0l-7 7a1 1 0 001.414 1.414L4 10.414V17a1 1 0 001 1h2a1 1 0 001-1v-2a1 1 0 011-1h2a1 1 0 011 1v2a1 1 0 001 1h2a1 1 0 001-1v-6.586l.293.293a1 1 0 001.414-1.414l-7-7z"></path></svg>
                <?php else: ?>                    
                    <svg class="w-4 h-4" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z" clip-rule="evenodd"></path></svg>                    
                <?php endif; ?>
                <a href="<?php echo e($link); ?>" class="<?php echo \Illuminate\Support\Arr::toCssClasses(["hover:underline hover:font-bold " => !$loop->last]); ?>">
                    <?php echo e($name); ?>

                </a>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ol>
  </nav>
<?php /**PATH C:\Users\connor\Desktop\CarLooker\resources\views/components/ui/breadcrumb.blade.php ENDPATH**/ ?>