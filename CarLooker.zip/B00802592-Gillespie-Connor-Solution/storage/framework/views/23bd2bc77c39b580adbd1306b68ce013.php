
<div <?php echo e($attributes->merge(['class' => "w-full px-6 py-4 shadow-lg overflow-hidden sm:rounded-lg border border-gray-200"])); ?>>

    <?php if(isset($header)): ?>
        <div <?php echo e($header->attributes->merge(['class'=>"pt-4 pb-2 mb-2 border-b border-gray-800"])); ?>>
            <?php echo e($header); ?>

        </div>
    <?php endif; ?>

    <?php echo e($slot); ?>


    <?php if(isset($footer)): ?>
        <div <?php echo e($footer->attributes->merge(['class'=>"py-4 mt-2 border-t border-gray-800"])); ?>>
            <?php echo e($footer); ?>

        </div>
    <?php endif; ?>

</div>


<?php /**PATH C:\Users\connor\Desktop\CarLooker\resources\views/components/ui/card.blade.php ENDPATH**/ ?>