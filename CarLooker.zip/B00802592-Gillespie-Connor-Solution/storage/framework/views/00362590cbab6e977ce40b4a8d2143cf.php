<!-- resources/views/components/CommunitySection.blade.php -->
<div class="bg-gray-100 py-12">
    <div class="container mx-auto text-center">
        <h2 class="text-3xl font-bold mb-4 text-gray-800">Join the CarLooker Community</h2>
        <p class="text-xl text-gray-600 mb-8">Sign up now and start managing your vehicle collection like a pro.</p>
        <a href="<?php echo e(route('register')); ?>" class="bg-blue-500 hover:bg-blue-600 text-white font-bold py-3 px-6 rounded-lg">Get Started</a>
    </div>
</div>
<?php /**PATH C:\Users\conno\CarLooker\resources\views/components/CommunitySection.blade.php ENDPATH**/ ?>