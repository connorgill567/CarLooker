<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23a33f287873b564aaf305a1526eada4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php if (isset($component)) { $__componentOriginal045477955e5b1d8c9df01934ca3836c0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal045477955e5b1d8c9df01934ca3836c0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.breadcrumb','data' => ['crumbs' => [
        'Home'=>route('home'),
        'Vehicles'=>route('vehicles.index'),
        $vehicle->id => route('vehicles.show',['id'=>$vehicle->id])
    ]]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('ui.breadcrumb'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['crumbs' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute([
        'Home'=>route('home'),
        'Vehicles'=>route('vehicles.index'),
        $vehicle->id => route('vehicles.show',['id'=>$vehicle->id])
    ])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal045477955e5b1d8c9df01934ca3836c0)): ?>
<?php $attributes = $__attributesOriginal045477955e5b1d8c9df01934ca3836c0; ?>
<?php unset($__attributesOriginal045477955e5b1d8c9df01934ca3836c0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal045477955e5b1d8c9df01934ca3836c0)): ?>
<?php $component = $__componentOriginal045477955e5b1d8c9df01934ca3836c0; ?>
<?php unset($__componentOriginal045477955e5b1d8c9df01934ca3836c0); ?>
<?php endif; ?>

    <!-- header -->
    <?php if (isset($component)) { $__componentOriginalea3ff48ecc2c47bd6007ee32944844eb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalea3ff48ecc2c47bd6007ee32944844eb = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.header','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('ui.header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
        <?php if (isset($component)) { $__componentOriginaleee9904a23975a5389c3cf9a8800e87b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaleee9904a23975a5389c3cf9a8800e87b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.title','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('ui.title'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>Vehicle Details <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaleee9904a23975a5389c3cf9a8800e87b)): ?>
<?php $attributes = $__attributesOriginaleee9904a23975a5389c3cf9a8800e87b; ?>
<?php unset($__attributesOriginaleee9904a23975a5389c3cf9a8800e87b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaleee9904a23975a5389c3cf9a8800e87b)): ?>
<?php $component = $__componentOriginaleee9904a23975a5389c3cf9a8800e87b; ?>
<?php unset($__componentOriginaleee9904a23975a5389c3cf9a8800e87b); ?>
<?php endif; ?>
        <!-- Back button -->
        <?php if (isset($component)) { $__componentOriginal606bedd6108050b8303bc7c381e2387c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal606bedd6108050b8303bc7c381e2387c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.link','data' => ['href' => ''.e(route('vehicles.index')).'','class' => 'flex gap-2 items-center']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('ui.link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => ''.e(route('vehicles.index')).'','class' => 'flex gap-2 items-center']); ?>
            <?php if (isset($component)) { $__componentOriginal151ca4090b35582230528f9d92f72311 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal151ca4090b35582230528f9d92f72311 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.svg.arrow','data' => ['left' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('ui.svg.arrow'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['left' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal151ca4090b35582230528f9d92f72311)): ?>
<?php $attributes = $__attributesOriginal151ca4090b35582230528f9d92f72311; ?>
<?php unset($__attributesOriginal151ca4090b35582230528f9d92f72311); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal151ca4090b35582230528f9d92f72311)): ?>
<?php $component = $__componentOriginal151ca4090b35582230528f9d92f72311; ?>
<?php unset($__componentOriginal151ca4090b35582230528f9d92f72311); ?>
<?php endif; ?>
            <span>Back</span>
          <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal606bedd6108050b8303bc7c381e2387c)): ?>
<?php $attributes = $__attributesOriginal606bedd6108050b8303bc7c381e2387c; ?>
<?php unset($__attributesOriginal606bedd6108050b8303bc7c381e2387c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal606bedd6108050b8303bc7c381e2387c)): ?>
<?php $component = $__componentOriginal606bedd6108050b8303bc7c381e2387c; ?>
<?php unset($__componentOriginal606bedd6108050b8303bc7c381e2387c); ?>
<?php endif; ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalea3ff48ecc2c47bd6007ee32944844eb)): ?>
<?php $attributes = $__attributesOriginalea3ff48ecc2c47bd6007ee32944844eb; ?>
<?php unset($__attributesOriginalea3ff48ecc2c47bd6007ee32944844eb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalea3ff48ecc2c47bd6007ee32944844eb)): ?>
<?php $component = $__componentOriginalea3ff48ecc2c47bd6007ee32944844eb; ?>
<?php unset($__componentOriginalea3ff48ecc2c47bd6007ee32944844eb); ?>
<?php endif; ?>

    <div class="flex gap-4">
        <!-- Vehicle details card -->
        <?php if (isset($component)) { $__componentOriginaldae4cd48acb67888a4631e1ba48f2f93 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldae4cd48acb67888a4631e1ba48f2f93 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.card','data' => ['class' => 'w-1/2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('ui.card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'w-1/2']); ?>
             <?php $__env->slot('header', null, ['class' => 'flex gap-2 items-center']); ?> 
                <?php if (isset($component)) { $__componentOriginaleee9904a23975a5389c3cf9a8800e87b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaleee9904a23975a5389c3cf9a8800e87b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.title','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('ui.title'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?><?php echo e($vehicle->make); ?> <?php echo e($vehicle->model); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaleee9904a23975a5389c3cf9a8800e87b)): ?>
<?php $attributes = $__attributesOriginaleee9904a23975a5389c3cf9a8800e87b; ?>
<?php unset($__attributesOriginaleee9904a23975a5389c3cf9a8800e87b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaleee9904a23975a5389c3cf9a8800e87b)): ?>
<?php $component = $__componentOriginaleee9904a23975a5389c3cf9a8800e87b; ?>
<?php unset($__componentOriginaleee9904a23975a5389c3cf9a8800e87b); ?>
<?php endif; ?>
             <?php $__env->endSlot(); ?>
            <!-- Vehicle image -->
            <?php if($vehicle->image): ?>
            <img src="<?php echo e(Storage::url($vehicle->image)); ?>" alt="<?php echo e($vehicle->make); ?> <?php echo e($vehicle->model); ?>" class="w-64">
        <?php endif; ?>
            <!-- Vehicle details -->
            <?php if (isset($component)) { $__componentOriginal17216831db500eec58b034f5575d0ae6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal17216831db500eec58b034f5575d0ae6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.display','data' => ['name' => 'Year','value' => ''.e($vehicle->year).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('ui.display'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'Year','value' => ''.e($vehicle->year).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal17216831db500eec58b034f5575d0ae6)): ?>
<?php $attributes = $__attributesOriginal17216831db500eec58b034f5575d0ae6; ?>
<?php unset($__attributesOriginal17216831db500eec58b034f5575d0ae6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal17216831db500eec58b034f5575d0ae6)): ?>
<?php $component = $__componentOriginal17216831db500eec58b034f5575d0ae6; ?>
<?php unset($__componentOriginal17216831db500eec58b034f5575d0ae6); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginal17216831db500eec58b034f5575d0ae6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal17216831db500eec58b034f5575d0ae6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.display','data' => ['name' => 'Registration','value' => ''.e($vehicle->registration).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('ui.display'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'Registration','value' => ''.e($vehicle->registration).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal17216831db500eec58b034f5575d0ae6)): ?>
<?php $attributes = $__attributesOriginal17216831db500eec58b034f5575d0ae6; ?>
<?php unset($__attributesOriginal17216831db500eec58b034f5575d0ae6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal17216831db500eec58b034f5575d0ae6)): ?>
<?php $component = $__componentOriginal17216831db500eec58b034f5575d0ae6; ?>
<?php unset($__componentOriginal17216831db500eec58b034f5575d0ae6); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginal17216831db500eec58b034f5575d0ae6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal17216831db500eec58b034f5575d0ae6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.display','data' => ['name' => 'Fuel Type','value' => ''.e($vehicle->fuel_type).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('ui.display'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'Fuel Type','value' => ''.e($vehicle->fuel_type).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal17216831db500eec58b034f5575d0ae6)): ?>
<?php $attributes = $__attributesOriginal17216831db500eec58b034f5575d0ae6; ?>
<?php unset($__attributesOriginal17216831db500eec58b034f5575d0ae6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal17216831db500eec58b034f5575d0ae6)): ?>
<?php $component = $__componentOriginal17216831db500eec58b034f5575d0ae6; ?>
<?php unset($__componentOriginal17216831db500eec58b034f5575d0ae6); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginal17216831db500eec58b034f5575d0ae6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal17216831db500eec58b034f5575d0ae6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.display','data' => ['name' => 'Body Type','value' => ''.e($vehicle->body_type).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('ui.display'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'Body Type','value' => ''.e($vehicle->body_type).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal17216831db500eec58b034f5575d0ae6)): ?>
<?php $attributes = $__attributesOriginal17216831db500eec58b034f5575d0ae6; ?>
<?php unset($__attributesOriginal17216831db500eec58b034f5575d0ae6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal17216831db500eec58b034f5575d0ae6)): ?>
<?php $component = $__componentOriginal17216831db500eec58b034f5575d0ae6; ?>
<?php unset($__componentOriginal17216831db500eec58b034f5575d0ae6); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginal17216831db500eec58b034f5575d0ae6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal17216831db500eec58b034f5575d0ae6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.display','data' => ['name' => 'Transmission Type','value' => ''.e($vehicle->transmission_type).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('ui.display'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'Transmission Type','value' => ''.e($vehicle->transmission_type).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal17216831db500eec58b034f5575d0ae6)): ?>
<?php $attributes = $__attributesOriginal17216831db500eec58b034f5575d0ae6; ?>
<?php unset($__attributesOriginal17216831db500eec58b034f5575d0ae6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal17216831db500eec58b034f5575d0ae6)): ?>
<?php $component = $__componentOriginal17216831db500eec58b034f5575d0ae6; ?>
<?php unset($__componentOriginal17216831db500eec58b034f5575d0ae6); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginal17216831db500eec58b034f5575d0ae6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal17216831db500eec58b034f5575d0ae6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.display','data' => ['name' => 'CC','value' => ''.e($vehicle->cc).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('ui.display'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'CC','value' => ''.e($vehicle->cc).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal17216831db500eec58b034f5575d0ae6)): ?>
<?php $attributes = $__attributesOriginal17216831db500eec58b034f5575d0ae6; ?>
<?php unset($__attributesOriginal17216831db500eec58b034f5575d0ae6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal17216831db500eec58b034f5575d0ae6)): ?>
<?php $component = $__componentOriginal17216831db500eec58b034f5575d0ae6; ?>
<?php unset($__componentOriginal17216831db500eec58b034f5575d0ae6); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginal17216831db500eec58b034f5575d0ae6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal17216831db500eec58b034f5575d0ae6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.display','data' => ['name' => 'No. Doors','value' => ''.e($vehicle->no_doors).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('ui.display'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'No. Doors','value' => ''.e($vehicle->no_doors).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal17216831db500eec58b034f5575d0ae6)): ?>
<?php $attributes = $__attributesOriginal17216831db500eec58b034f5575d0ae6; ?>
<?php unset($__attributesOriginal17216831db500eec58b034f5575d0ae6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal17216831db500eec58b034f5575d0ae6)): ?>
<?php $component = $__componentOriginal17216831db500eec58b034f5575d0ae6; ?>
<?php unset($__componentOriginal17216831db500eec58b034f5575d0ae6); ?>
<?php endif; ?>
            <div class="flex gap-3 mt-4">
                <!-- Vehicle edit button -->
                <?php if (isset($component)) { $__componentOriginal606bedd6108050b8303bc7c381e2387c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal606bedd6108050b8303bc7c381e2387c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.link','data' => ['variant' => 'blue','href' => ''.e(route('vehicles.edit', ['id' => $vehicle->id])).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('ui.link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['variant' => 'blue','href' => ''.e(route('vehicles.edit', ['id' => $vehicle->id])).'']); ?>
                    Edit
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal606bedd6108050b8303bc7c381e2387c)): ?>
<?php $attributes = $__attributesOriginal606bedd6108050b8303bc7c381e2387c; ?>
<?php unset($__attributesOriginal606bedd6108050b8303bc7c381e2387c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal606bedd6108050b8303bc7c381e2387c)): ?>
<?php $component = $__componentOriginal606bedd6108050b8303bc7c381e2387c; ?>
<?php unset($__componentOriginal606bedd6108050b8303bc7c381e2387c); ?>
<?php endif; ?>
                <!-- Vehicle delete button -->
                <?php if (isset($component)) { $__componentOriginal606bedd6108050b8303bc7c381e2387c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal606bedd6108050b8303bc7c381e2387c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.link','data' => ['variant' => 'red','href' => ''.e(route('vehicles.delete', ['id' => $vehicle->id])).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('ui.link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['variant' => 'red','href' => ''.e(route('vehicles.delete', ['id' => $vehicle->id])).'']); ?>
                    Delete
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal606bedd6108050b8303bc7c381e2387c)): ?>
<?php $attributes = $__attributesOriginal606bedd6108050b8303bc7c381e2387c; ?>
<?php unset($__attributesOriginal606bedd6108050b8303bc7c381e2387c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal606bedd6108050b8303bc7c381e2387c)): ?>
<?php $component = $__componentOriginal606bedd6108050b8303bc7c381e2387c; ?>
<?php unset($__componentOriginal606bedd6108050b8303bc7c381e2387c); ?>
<?php endif; ?>
            </div>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldae4cd48acb67888a4631e1ba48f2f93)): ?>
<?php $attributes = $__attributesOriginaldae4cd48acb67888a4631e1ba48f2f93; ?>
<?php unset($__attributesOriginaldae4cd48acb67888a4631e1ba48f2f93); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldae4cd48acb67888a4631e1ba48f2f93)): ?>
<?php $component = $__componentOriginaldae4cd48acb67888a4631e1ba48f2f93; ?>
<?php unset($__componentOriginaldae4cd48acb67888a4631e1ba48f2f93); ?>
<?php endif; ?>

        <!-- Service history card -->
        <?php if (isset($component)) { $__componentOriginaldae4cd48acb67888a4631e1ba48f2f93 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldae4cd48acb67888a4631e1ba48f2f93 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.card','data' => ['class' => 'w-1/2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('ui.card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'w-1/2']); ?>
             <?php $__env->slot('header', null, []); ?> 
                <?php if (isset($component)) { $__componentOriginaleee9904a23975a5389c3cf9a8800e87b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaleee9904a23975a5389c3cf9a8800e87b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.title','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('ui.title'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>Service History <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaleee9904a23975a5389c3cf9a8800e87b)): ?>
<?php $attributes = $__attributesOriginaleee9904a23975a5389c3cf9a8800e87b; ?>
<?php unset($__attributesOriginaleee9904a23975a5389c3cf9a8800e87b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaleee9904a23975a5389c3cf9a8800e87b)): ?>
<?php $component = $__componentOriginaleee9904a23975a5389c3cf9a8800e87b; ?>
<?php unset($__componentOriginaleee9904a23975a5389c3cf9a8800e87b); ?>
<?php endif; ?>
             <?php $__env->endSlot(); ?>

            <table class="w-full">
                <thead>
                    <tr>
                        <!-- Service record headings -->
                        <th class="px-4 py-2">Service Date</th>
                        <th class="px-4 py-2">By</th>
                        <th class="px-4 py-2">Mileage</th>
                        <th class="px-4 py-2">Cost</th>
                        <th class="px-4 py-2">Description</th>
                    </tr>
                </thead>
                <tbody>
                    <!-- Service record information -->
                    <?php $__currentLoopData = $vehicle->serviceRecords; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="border px-4 py-2"><?php echo e($record->service_date); ?></td>
                            <td class="border px-4 py-2"><?php echo e($record->service_by); ?></td>
                            <td class="border px-4 py-2"><?php echo e($record->mileage); ?></td>
                            <td class="border px-4 py-2"><?php echo e($record->cost); ?></td>
                            <td class="border px-4 py-2"><?php echo e($record->description); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <div class="flex gap-3 mt-4">
                <!-- Add a new service record for the vehicle -->
                <?php if (isset($component)) { $__componentOriginal606bedd6108050b8303bc7c381e2387c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal606bedd6108050b8303bc7c381e2387c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.link','data' => ['variant' => 'blue','href' => ''.e(route('vehicles.addService', ['id' => $vehicle->id])).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('ui.link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['variant' => 'blue','href' => ''.e(route('vehicles.addService', ['id' => $vehicle->id])).'']); ?>
                    Add Service
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal606bedd6108050b8303bc7c381e2387c)): ?>
<?php $attributes = $__attributesOriginal606bedd6108050b8303bc7c381e2387c; ?>
<?php unset($__attributesOriginal606bedd6108050b8303bc7c381e2387c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal606bedd6108050b8303bc7c381e2387c)): ?>
<?php $component = $__componentOriginal606bedd6108050b8303bc7c381e2387c; ?>
<?php unset($__componentOriginal606bedd6108050b8303bc7c381e2387c); ?>
<?php endif; ?>
                <?php $__currentLoopData = $vehicle->serviceRecords; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <!-- Edit a service record for the vehicle -->
                    <?php if (isset($component)) { $__componentOriginal606bedd6108050b8303bc7c381e2387c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal606bedd6108050b8303bc7c381e2387c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.link','data' => ['variant' => 'blue','href' => ''.e(route('service-records.edit', ['id' => $record->id])).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('ui.link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['variant' => 'blue','href' => ''.e(route('service-records.edit', ['id' => $record->id])).'']); ?>
                        Edit Service
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal606bedd6108050b8303bc7c381e2387c)): ?>
<?php $attributes = $__attributesOriginal606bedd6108050b8303bc7c381e2387c; ?>
<?php unset($__attributesOriginal606bedd6108050b8303bc7c381e2387c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal606bedd6108050b8303bc7c381e2387c)): ?>
<?php $component = $__componentOriginal606bedd6108050b8303bc7c381e2387c; ?>
<?php unset($__componentOriginal606bedd6108050b8303bc7c381e2387c); ?>
<?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php $__currentLoopData = $vehicle->serviceRecords; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <!-- Delete a service record for the vehicle -->
                <?php if (isset($component)) { $__componentOriginal606bedd6108050b8303bc7c381e2387c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal606bedd6108050b8303bc7c381e2387c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.link','data' => ['variant' => 'red','href' => ''.e(route('service-records.delete', ['id' => $vehicle->id])).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('ui.link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['variant' => 'red','href' => ''.e(route('service-records.delete', ['id' => $vehicle->id])).'']); ?>
                    Delete Service
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal606bedd6108050b8303bc7c381e2387c)): ?>
<?php $attributes = $__attributesOriginal606bedd6108050b8303bc7c381e2387c; ?>
<?php unset($__attributesOriginal606bedd6108050b8303bc7c381e2387c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal606bedd6108050b8303bc7c381e2387c)): ?>
<?php $component = $__componentOriginal606bedd6108050b8303bc7c381e2387c; ?>
<?php unset($__componentOriginal606bedd6108050b8303bc7c381e2387c); ?>
<?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldae4cd48acb67888a4631e1ba48f2f93)): ?>
<?php $attributes = $__attributesOriginaldae4cd48acb67888a4631e1ba48f2f93; ?>
<?php unset($__attributesOriginaldae4cd48acb67888a4631e1ba48f2f93); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldae4cd48acb67888a4631e1ba48f2f93)): ?>
<?php $component = $__componentOriginaldae4cd48acb67888a4631e1ba48f2f93; ?>
<?php unset($__componentOriginaldae4cd48acb67888a4631e1ba48f2f93); ?>
<?php endif; ?>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $attributes = $__attributesOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__attributesOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php /**PATH C:\Users\conno\CarLooker\resources\views/vehicle/show.blade.php ENDPATH**/ ?>