<th scope="col" <?php echo e($attributes->merge(['class' => 'px-3 py-2 text-sm text-left font-bold text-gray-900 uppercase'])); ?> >
    <?php echo e($slot); ?>

</th>
<?php /**PATH C:\Users\connor\Desktop\CarLooker\resources\views/components/ui/table/col.blade.php ENDPATH**/ ?>