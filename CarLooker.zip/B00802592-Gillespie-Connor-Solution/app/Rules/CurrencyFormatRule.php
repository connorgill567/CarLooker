<?php

namespace App\Rules;

use Illuminate\Contracts\Validation\Rule;

class CurrencyFormatRule implements Rule
{
    /**
     * Determine if the validation rule passes.
     *
     * @param  string  $attribute
     * @param  mixed  $value
     * @return bool
     */
    public function passes($attribute, $value)
    {
        $pattern = '/^(£|$|€)\d+(\.\d{2})?$/i';
        return preg_match($pattern, $value) === 1;
    }

    /**
     * Get the validation error message.
     *
     * @return string
     */
    public function message()
    {
        return 'The :attribute must be in a valid currency format (e.g., £100.00, $40.50, €75).';
    }
}
