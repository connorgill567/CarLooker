<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;

class PageController extends Controller
{
    //routing for home page
    public function home()
    {
        return view('home');
    }
    //routing for about page
    public function about()
    {
        return view('about');
    }
    //routing for the search page
    public function searchform()
    {
        return view('search-vehicle');
    }
    //routing for contact page
    public function contact()
    {
        return view('contact');
    }
}
