<?php

namespace App\Http\Controllers;

use App\Enums\Role;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;
use Illuminate\Support\Facades\Auth;

class UserController extends Controller
{
    /**
     * Show the form for creating a new user.
     */
    public function create()
    {
        return view('user.register', ['user' => new User]);
    }

    /**
     * Storing the information of the new user
     */
    public function store(Request $request)
    {
        // validate request form values
        $credentials = $request->validate([
            'name'  => ['required'],
            'email' => ['required', 'email', 'unique:users'],
            'password' => ['confirmed', 'min:6']
        ]);

        // assign the USER role to the user
        $credentials['role'] = Role::USER->value;

        // create user
        $user = User::create($credentials);

        // login newly authenticated user
        Auth::login($user);

        return redirect()->route("home")
                ->with('success', "Logged in Successfully");
    }


    /**
     * Show the form for login to CarLooker.
     */
    public function login()
    {
        return view('user.login', ['user' => new User]);
    }

    /**
     * authenticatiing the user details
     */
    public function authenticate(Request $request)
    {
        $credentials = $request->validate([
            'email' => ['required', 'email'],
            'password' => ['required']
        ]);
        if (Auth::attempt($credentials) ) {
            $request->session()->regenerate();
            return redirect()->route("home")
                             ->with('success', "Logged in Successfully");
        }
        return redirect()->back()->withErrors(
            [
                'email' => 'Invalid credentials',
                'password' => 'Invalid credentials'
            ]
        );
    }

    public function logout(Request $request) {
        // remove the authentication information from the user's session
        auth()->logout();
        // invalidate the user session
        $request->session()->invalidate();
        // regenerate the CSRF token
        $request->session()->regenerateToken();

        return redirect()->route("login")
                         ->with('success', "Successfully logged out");
    }
}
