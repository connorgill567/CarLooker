<?php

namespace App\Http\Controllers;

use App\Models\Vehicle;
use App\Models\Category;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;
use Illuminate\Support\Facades\Gate;

class VehicleController extends Controller
{
    /**
     * Display the list of vehicles.
     */
    public function index(Request $request)
{
    Gate::authorize('viewAny', Vehicle::class);

    $search    = $request->input('search');
    $size      = $request->query('size') ?? 5;
    $sort      = $request->query('sort') ?? 'id';
    $direction = $request->query('direction') ?? 'asc';

    $vehicles = Vehicle::with(['category'])
        ->sortable($sort, $direction)
        ->paginate($size)
        ->withQueryString();

    return view('vehicle.index', ['vehicles' => $vehicles, "search" => $search]);
}

    /**
     * Show the form for creating a new vehicle page.
     */
    public function create()
    {

        $categories = Category::all()->pluck('name', 'id');

        return view('vehicle.create', ['vehicle' => new Vehicle, 'categories' => $categories]);
    }

    /**
     * Store vehicle information in storage.
     */
    public function store(Request $request)
    {
        $data = $request->validate([
            'make' => 'required|string|max:255',
            'model' => 'required|string|max:255',
            'year' => 'required|integer|min:1900|max:2024',
            'registration' => 'required|string|max:8|unique:vehicles,registration,',
            'fuel_type' => 'required|in:Diesel,Petrol,Electric,Hybrid',
            'body_type' => 'required|string|max:255',
            'transmission_type' => 'required|in:Manual,Automatic',
            'cc' => 'required|integer|min:0|max:10000',
            'no_doors' => 'required|integer|min:2|max:5',
            'image' => 'image|mimes:jpg,jpeg,png|max:8000',
        ]);

        if ($request->hasFile('image')) {
            // store the image in the public vehicles folder
            $data['image'] = $request->image->store('vehicles', 'public');
        }


        $vehicle = new Vehicle($data);
        $vehicle->save();

        return redirect()->route('vehicles.show', ['id' => $vehicle->id])
            ->with('success', 'Vehicle created successfully.');
    }


    /**
     * Display the specific vehicle requested by the user.
     */
    public function show(int $id, Request $request)
    {
        $vehicle = Vehicle::findorfail($id);

        Gate::authorize('view', $vehicle);
        return view('vehicle.show', ['vehicle' => $vehicle]);
    }

    /**
     * Show the form for editing vehicle information.
     */
    public function edit(int $id)
    {
        $vehicle = Vehicle::findOrFail($id);

        Gate::authorize('view', $vehicle);

        $categories = Category::all()->pluck('id');
        return view('vehicle.edit', ['vehicle' => $vehicle, 'categories' => $categories]);
    }

    /**
     * Update the information regarding the vehicle.
     */
    public function update(Request $request, int $id)
    {
        $vehicle = Vehicle::findOrFail($id);
        $data = $request->validate([
            'make' => 'required|string|max:255',
            'model' => 'required|string|max:255',
            'year' => 'required|integer|min:1900|max:2024',
            'registration' => 'required', 'string', 'max:8', Rule::unique('vehicles', 'registration')->ignore($vehicle->id),
            'fuel_type' => 'required|in:Diesel,Petrol,Electric,Hybrid',
            'body_type' => 'required|string|max:255',
            'transmission_type' => 'required|in:Manual,Automatic',
            'cc' => 'required|integer|min:0|max:10000',
            'no_doors' => 'required|integer|min:2|max:5',
            'image' => 'image|mimes:jpg,jpeg,png|max:8000',
        ]);

        if ($request->hasFile('image')) {
            // store the image in the public vehicles folder
            $data['image'] = $request->image->store('vehicles', 'public');
        }

        $vehicle->update($data);

        return redirect()->route('vehicles.show', ['id' => $vehicle->id])
            ->with('success', 'Vehicle updated successfully.');
    }

    /**
     * Remove the vehicle from database.
     */
    public function destroy(int $id)
    {
        $vehicle = Vehicle::findOrFail($id);

        Gate::authorize('view', $vehicle);

        $vehicle->delete();
        return redirect()->route('vehicles.index')
            ->with('success', 'Vehicle deleted successfully.');
    }

    /**
     * navigation search bar
     */
    public function search(Request $request)
    {
        $query = Vehicle::query();

        if ($request->has('search')) {
            $searchTerm = $request->input('search');
            $query->where(function ($q) use ($searchTerm) {
                $q->where('make', 'like', '%' . $searchTerm . '%')
                    ->orWhere('model', 'like', '%' . $searchTerm . '%')
                    ->orWhere('year', 'like', '%' . $searchTerm . '%')
                    ->orWhere('fuel_type', 'like', '%' . $searchTerm . '%')
                    ->orWhere('transmission_type', 'like', '%' . $searchTerm . '%');
            });
        }

        if ($request->has('fuel_type') && $request->input('fuel_type') !== '') {
            $query->where('fuel_type', $request->input('fuel_type'));
        }

        if ($request->has('transmission_type') && $request->input('transmission_type') !== '') {
            $query->where('transmission_type', $request->input('transmission_type'));
        }

        $vehicles = $query->paginate(10);

        return view('vehicle.index', compact('vehicles'));
    }
    /**
     * search page
     */
    public function advancedSearch(Request $request)
    {
        $query = Vehicle::query();

        if ($request->filled('make')) {
            $query->where('make', 'LIKE', "%{$request->make}%");
        }

        if ($request->filled('model')) {
            $query->where('model', 'LIKE', "%{$request->model}%");
        }

        if ($request->filled('year')) {
            $query->where('year', $request->year);
        }

        if ($request->filled('fuel_type')) {
            $query->where('fuel_type', $request->fuel_type);
        }

        if ($request->filled('body_type')) {
            $query->where('body_type', 'LIKE', "%{$request->body_type}%");
        }

        if ($request->filled('transmission_type')) {
            $query->where('transmission_type', $request->transmission_type);
        }

        if ($request->filled('cc')) {
            $query->where('cc', $request->cc);
        }

        if ($request->filled('no_doors')) {
            $query->where('no_doors', $request->no_doors);
        }

        $vehicles = $query->paginate(5);

        if ($vehicles->isEmpty()) {
            // Redirect back to the search page with a warning message if inputs dont match the vehicle information
            return redirect()->back()->with('warning', 'No vehicles found. Please try adjusting your search criteria.');
        }
        return view('vehicle.index', compact('vehicles'));
    }
    // redirects the user to the confirmation page of deleting a vehicle
    public function deleteConfirmVehicle($id)
    {
        $vehicle = Vehicle::findOrFail($id);
        return view('vehicle.delete', ['vehicle' => $vehicle]);
    }
}
