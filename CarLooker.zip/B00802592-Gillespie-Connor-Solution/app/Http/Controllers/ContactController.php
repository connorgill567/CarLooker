<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ContactController extends Controller
{
    public function submit(Request $request)
    {
        // Validate the form data
        $validatedData = $request->validate([
            'name' => 'required',
            'email' => 'required|email',
            'message' => 'required',
        ]);

        // Process the form data (e.g., send an email, store in the database)
        // ...

        // Redirect back with a success message
        return redirect()->back()->with('success', 'Thank you for contacting us! We will get back to you soon.');
    }
}