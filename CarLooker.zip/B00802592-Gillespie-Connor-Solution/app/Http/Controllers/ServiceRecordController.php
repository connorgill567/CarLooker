<?php

namespace App\Http\Controllers;

use App\Models\Vehicle;
use Illuminate\Http\Request;
use App\Models\ServiceRecord;
use App\Rules\CurrencyFormatRule;

class ServiceRecordController extends Controller
{
    //creating a service record and applying it to the vehicle
    public function store(Request $request, $vehicleId)
    {
        $vehicle = Vehicle::findOrFail($vehicleId);

        $validatedData = $request->validate([
            'service_date' => 'required|date',
            'service_by' => 'required|string',
            'mileage' => 'required|integer',
            'cost' => ['required', new CurrencyFormatRule],
            'description' => 'required|string',
        ]);

        $serviceRecord = new ServiceRecord($validatedData);
        $serviceRecord->vehicle()->associate($vehicle);
        $serviceRecord->save();

        return redirect()->route('vehicles.show', ['id' => $vehicle->id])
            ->with('success', 'Service record added successfully.');
    }

    //route to the edit service page
    public function edit($id)
    {
        $serviceRecord = ServiceRecord::findOrFail($id);
        return view('service-records.edit', ['serviceRecord' => $serviceRecord]);
    }

//validation for updating service record information and redirecting the user to vehicle page after updating
public function update(Request $request, $id)
{
    $serviceRecord = ServiceRecord::findOrFail($id);
    $validatedData = $request->validate([
        'service_date' => 'required|date',
        'service_by' => 'required|string',
        'mileage' => 'required|integer',
        'cost' => ['required', new CurrencyFormatRule],
        'description' => 'required|string',

    ]);

    $serviceRecord->update($validatedData);

    return redirect()->route('vehicles.show', ['id' => $serviceRecord->vehicle->id])
        ->with('success', 'Service record updated successfully.');
}
    //removing a service record and redirecting the user to the vehicle list
    public function destroy($id)
    {
        $serviceRecord = ServiceRecord::findOrFail($id);
        $vehicleId = $serviceRecord->vehicle_id;
        $serviceRecord->delete();

        return redirect()->route('vehicles.show', ['id' => $vehicleId])
            ->with('success', 'Service record deleted successfully.');
    }
    //directs the user to the service create page
    public function create($vehicleId)
{
    $vehicle = Vehicle::findOrFail($vehicleId);
    return view('service-records.create', ['vehicle' => $vehicle]);
}
    //directs the user to the service delete page
public function deleteConfirmService($id)
{
    $vehicle = Vehicle::findOrFail($id);
    return view('service-records.delete', ['vehicle' => $vehicle]);
}
}
