<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use App\Traits\Sortable;

class Vehicle extends Model
{
    use HasFactory, Sortable;


    protected $fillable = [
        'make',
        'model',
        'year',
        'registration',
        'fuel_type',
        'body_type',
        'transmission_type',
        'cc',
        'no_doors',
        'image',
        'image_path',
    ];

    // Define BelongsTo category relationship
    public function category(): BelongsTo
    {
        return $this->belongsTo(Category::class);
    }

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function serviceRecords()
    {
        return $this->hasMany(ServiceRecord::class);
    }
    public function vehicles()
{
    return $this->hasMany(Vehicle::class);
}
public function scopeSearch($query, $search)
{
    return $query->where(function ($q) use ($search) {
        $q->where('make', 'like', '%' . $search . '%')
            ->orWhere('model', 'like', '%' . $search . '%')
            ->orWhere('year', 'like', '%' . $search . '%')
            ->orWhere('fuel_type', 'like', '%' . $search . '%')
            ->orWhere('transmission_type', 'like', '%' . $search . '%');
    });
}
}
