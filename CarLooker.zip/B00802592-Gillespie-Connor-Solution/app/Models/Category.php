<?php

namespace App\Models;

use App\Traits\Sortable;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Category extends Model
{
    use HasFactory , Sortable;

    protected $guarded = [ 'id' ];

    // tbc - define HasMany vehicle relationship
    public function vehicle(): HasMany {
        return $this->hasMany(Vehicle::class);
    }

}
