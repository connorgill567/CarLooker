<?php

namespace App\Providers;

use App\Enums\Role;
use App\Models\Book;
use App\Models\User;
use App\Policies\BookPolicy;
use Illuminate\Support\Facades\Gate;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     */
    public function register(): void
    {
        //
    }

    /**
     * Bootstrap any application services.
     */
    public function boot(): void
    {
        //Model::preventLazyLoading(! $this->app->isProduction());
        
        Gate::define('delete-book', function (User $user) { 
             return $user->role == Role::ADMIN;
        });
        Gate::define('delete-review', function (User $user) { 
            return $user->role == Role::ADMIN;
       });
    }
}
