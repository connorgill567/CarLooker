<?php

use App\Models\Vehicle;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\UserController;
use App\Http\Controllers\ReviewController;
use App\Http\Controllers\ContactController;
use App\Http\Controllers\PageController;
use App\Http\Controllers\VehicleController;
use App\Http\Controllers\ServiceRecordController;



Route::get('/', [PageController::class, 'home'])->name('home');


Route::get('/about', [PageController::class, 'about'])->name('about');


Route::get('/contact', [PageController::class, 'contact'])->name('contact');


// Route for the search results (handled by the controller)

Route::post('/contact', [ContactController::class, 'submit'])->name('contact.submit');

Route::middleware(['auth'])->group(function () {
    // display all vehicles
    Route::get("/vehicles", [VehicleController::class, 'index'])->name('vehicles.index');

    // display create vehicle form note: must come before /vehicles/{id}
    Route::get("/vehicles/create", [VehicleController::class, 'create'])->name('vehicles.create');

    // create the vehicle
    Route::post("/vehicles", [VehicleController::class, 'store'])->name('vehicles.store');

    // display a vehicle identified by {id} route parameter
    Route::get('/vehicles/{id}', [VehicleController::class, 'show'])->whereNumber('id')->name('vehicles.show');
    // display form to edit a vehicle identified by {id} route parameter
    Route::get("/vehicles/{id}/edit", [VehicleController::class, 'edit'])->name('vehicles.edit');

    // update a vehicle
    Route::put('/vehicles/{id}', [VehicleController::class, 'update'])->name('vehicles.update');
    // delete a vehicle
    Route::delete("/vehicles/{id}", [VehicleController::class, 'destroy'])->name('vehicles.destroy');

    Route::get('/vehicles/search', [VehicleController::class, 'search'])->name('vehicles.search');


    Route::post('/vehicles/{id}/service-records', [ServiceRecordController::class, 'store'])->name('service-records.store');
    Route::get('/vehicles/{id}/service-records/edit', [ServiceRecordController::class, 'edit'])->name('service-records.edit');
    Route::put('/service-records/{id}', [ServiceRecordController::class, 'update'])->name('service-records.update');
    Route::delete('/service-records/{id}', [ServiceRecordController::class, 'destroy'])->name('service-records.destroy');


    Route::get('/vehicles/{id}/service-records/create', [ServiceRecordController::class, 'create'])->name('vehicles.addService');
    Route::get('/vehicle/search-vehicle', [PageController::class, 'searchform'])->name('search-vehicle');

Route::get('/vehicles/advanced-search', [VehicleController::class, 'advancedSearch'])->name('vehicles.advancedSearch');

Route::get('/vehicles/{id}/delete-confirm', [VehicleController::class, 'deleteConfirmVehicle'])->name('vehicles.delete');

Route::get('/service-records/{id}/delete-confirm', [ServiceRecordController::class, 'deleteConfirmService'])->name('service-records.delete');
  });

Route::post("/logout", [UserController::class, "logout"])->middleware('auth')->name("logout");

Route::middleware('guest')->group(function () {
    Route::get("/register",[UserController::class, "create"])->name("register");
    Route::post("/register",[UserController::class, "store"]);

    Route::get("/login",[UserController::class, "login"])->name("login");
    Route::post("/login",[UserController::class, "authenticate"]);
});
