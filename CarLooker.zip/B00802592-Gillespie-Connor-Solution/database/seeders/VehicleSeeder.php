<?php

namespace Database\Seeders;

use App\Models\Vehicle;
use Illuminate\Database\Seeder;

class VehicleSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $v1 = Vehicle::create([
            'make' => 'Toyota',
            'model' => 'Camry',
            'year' => 2019,
            'registration' => 'XY19 ABC',
            'fuel_type' => 'Petrol',
            'body_type' => 'Sedan',
            'transmission_type' => 'Automatic',
            'cc' => 2500,
            'no_doors' => 4,
            'image' => 'upload.placeholder.jpg'
        ]);

        $v2 = Vehicle::create([
            'make' => 'Ford',
            'model' => 'Fiesta',
            'year' => 2020,
            'registration' => 'AB12 CDE',
            'fuel_type' => 'Petrol',
            'body_type' => 'Hatchback',
            'transmission_type' => 'Automatic',
            'cc' => 1200,
            'no_doors' => 3,
            'image' => 'upload.placeholder.jpg'
        ]);

        $v3 = Vehicle::create([
            'make' => 'Tesla',
            'model' => 'Model S',
            'year' => 2022,
            'registration' => 'EL33 CTR',
            'fuel_type' => 'Electric',
            'body_type' => 'Sedan',
            'transmission_type' => 'Automatic',
            'cc' => 0,
            'no_doors' => 4,
            'image' => 'upload.placeholder.jpg'
        ]);

        $v4 = Vehicle::create([
            'make' => 'Honda',
            'model' => 'Civic',
            'year' => 2021,
            'registration' => 'CV21 XYZ',
            'fuel_type' => 'Petrol',
            'body_type' => 'Sedan',
            'transmission_type' => 'Manual',
            'cc' => 1800,
            'no_doors' => 4,
            'image' => 'upload.placeholder.jpg'
        ]);

        $v5 = Vehicle::create([
            'make' => 'BMW',
            'model' => 'X5',
            'year' => 2020,
            'registration' => 'BM20 SUV',
            'fuel_type' => 'Diesel',
            'body_type' => 'SUV',
            'transmission_type' => 'Automatic',
            'cc' => 3000,
            'no_doors' => 5,
            'image' => 'upload.placeholder.jpg'
        ]);

        $v6 = Vehicle::create([
            'make' => 'Audi',
            'model' => 'A4',
            'year' => 2019,
            'registration' => 'AU19 ABC',
            'fuel_type' => 'Petrol',
            'body_type' => 'Sedan',
            'transmission_type' => 'Automatic',
            'cc' => 2000,
            'no_doors' => 4,
            'image' => 'upload.placeholder.jpg'
        ]);

        $v7 = Vehicle::create([
            'make' => 'Mazda',
            'model' => 'CX-5',
            'year' => 2022,
            'registration' => 'MZ22 CX5',
            'fuel_type' => 'Petrol',
            'body_type' => 'SUV',
            'transmission_type' => 'Automatic',
            'cc' => 2500,
            'no_doors' => 5,
            'image' => 'upload.placeholder.jpg'
        ]);

        $v8 = Vehicle::create([
            'make' => 'Volkswagen',
            'model' => 'Golf',
            'year' => 2021,
            'registration' => 'VW21 GLF',
            'fuel_type' => 'Petrol',
            'body_type' => 'Hatchback',
            'transmission_type' => 'Manual',
            'cc' => 1500,
            'no_doors' => 5,
            'image' => 'upload.placeholder.jpg'
        ]);

        $v9 = Vehicle::create([
            'make' => 'Hyundai',
            'model' => 'Tucson',
            'year' => 2020,
            'registration' => 'HY20 TUC',
            'fuel_type' => 'Petrol',
            'body_type' => 'SUV',
            'transmission_type' => 'Automatic',
            'cc' => 2000,
            'no_doors' => 5,
            'image' => 'upload.placeholder.jpg'
        ]);

        $v10 = Vehicle::create([
            'make' => 'Nissan',
            'model' => 'Leaf',
            'year' => 2022,
            'registration' => 'NS22 LF',
            'fuel_type' => 'Electric',
            'body_type' => 'Hatchback',
            'transmission_type' => 'Automatic',
            'cc' => 0,
            'no_doors' => 5,
            'image' => 'upload.placeholder.jpg'
        ]);
    }
}
