<?php

namespace Database\Factories;

use Illuminate\Support\Str;
use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\Book>
 */
class VehicleFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        return [
            'image' => fake()->imageUrl(640, 480, 'cars', true, 'Faker'),
            'make' => fake()->word(),
            'model' => fake()->word(),
            'year' => fake()->numberBetween(1990, 2024),
            'registration' => fake()->regexify('[A-Z]{3}[0-9]{4}'),
            'fuel_type' => fake()->randomElement(['Diesel', 'Petrol', 'Electric', 'Hybrid']),
            'body_type' => fake()->word(),
            'transmission_type' => fake()->randomElement(['Manual', 'Automatic']),
            'cc' => fake()->numberBetween(1000, 5000),
            'no_doors' => fake()->numberBetween(2, 5)
        ];
    }
}
